import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
  }).index("by_token", ["tokenIdentifier"]),

  // RHK (Rencana Hasil Kerja) + Rencana Aksi per pegawai, sesuai target SKP
  rhk: defineTable({
    userId: v.id("users"),
    nomor: v.number(),
    namaRhk: v.string(),
    rencanaAksi: v.string(),
    targetKuantitas: v.number(),
    satuan: v.string(),
    // Kata kunci untuk memetakan judul foto ke RHK ini (dibatasi maks 20)
    kataKunci: v.array(v.string()),
    // Public Drive folder "RHK n, Nama" under "RHK RENCANA AKSI", created on sync
    driveFolderId: v.optional(v.string()),
    driveFolderName: v.optional(v.string()),
    driveLink: v.optional(v.string()),
  }).index("by_user_and_nomor", ["userId", "nomor"]),

  // Google Drive OAuth tokens per user. Never returned to the client.
  driveConnections: defineTable({
    userId: v.id("users"),
    googleEmail: v.string(),
    refreshToken: v.string(),
    accessToken: v.string(),
    accessTokenExpiresAt: v.string(),
    rawFolderId: v.optional(v.string()),
    rawFolderName: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  // One row per activity: photos with the same title on the same day share a row + Drive folder link
  laporanHarian: defineTable({
    userId: v.id("users"),
    // Grouping key "YYYY-MM-DD|judul lowercased", never edited so new photos keep merging
    kunciGrup: v.string(),
    tanggal: v.string(), // YYYY-MM-DD, editable
    jamKegiatan: v.string(), // HH.mm.ss, earliest photo time, editable
    namaKegiatan: v.string(),
    lokasi: v.optional(v.string()),
    uraian: v.string(),
    uraianStatus: v.union(v.literal("pending"), v.literal("ai"), v.literal("manual"), v.literal("error")),
    driveFolderId: v.string(),
    driveLink: v.string(),
    jumlahFoto: v.number(),
    // Drive shortcut of this activity folder placed inside the matched RHK folder
    rhkShortcutRhkId: v.optional(v.id("rhk")),
    rhkShortcutId: v.optional(v.string()),
  })
    .index("by_user_and_kunciGrup", ["userId", "kunciGrup"])
    .index("by_user_and_tanggal", ["userId", "tanggal"]),

  // Identitas pegawai ASN + atasan langsung (penilai kinerja), satu per user
  profilPegawai: defineTable({
    userId: v.id("users"),
    namaLengkap: v.string(),
    nip: v.string(),
    pangkat: v.string(),
    jabatan: v.string(),
    atasanNama: v.string(),
    atasanNip: v.string(),
    atasanPangkat: v.string(),
    atasanJabatan: v.string(),
    fotoId: v.optional(v.id("_storage")),
  }).index("by_user", ["userId"]),

  // Short-lived, single-use OAuth state tokens (CSRF protection)
  oauthStates: defineTable({
    state: v.string(),
    userId: v.id("users"),
    expiresAt: v.string(),
  }).index("by_state", ["state"]),
});
