import { describe, expect, it } from "vitest";
import { parsePhotoName } from "./parsePhotoName.ts";

describe("parsePhotoName", () => {
  it("parses compact Timemark format with location", () => {
    expect(parsePhotoName("20261027_115052_No. 35, Jalan Soekarno Hatta_Judul-routing gaji ASN.jpg")).toEqual({
      tanggal: "2026-10-27",
      jam: "11.50.52",
      judul: "routing gaji ASN",
      lokasi: "No. 35, Jalan Soekarno Hatta",
    });
  });

  it("parses dashed date with dotted time and parenthesised title", () => {
    expect(parsePhotoName("2026-10-03 08.15.32__(Judul-input pajak bulan Juli).jpg")).toEqual({
      tanggal: "2026-10-03",
      jam: "08.15.32",
      judul: "input pajak bulan Juli",
      lokasi: null,
    });
  });

  it("falls back to remaining text when no Judul marker", () => {
    expect(parsePhotoName("2026-08-02 07:05:00 rapat koordinasi.png")?.judul).toBe("rapat koordinasi");
  });

  it("rejects names without a valid date", () => {
    expect(parsePhotoName("IMG_1234.jpg")).toBeNull();
    expect(parsePhotoName("20261340_101010_Judul-x.jpg")).toBeNull();
  });
});
