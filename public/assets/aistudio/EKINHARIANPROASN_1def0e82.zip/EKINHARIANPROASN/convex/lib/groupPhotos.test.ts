import { describe, expect, it } from "vitest";
import { groupPhotos } from "./groupPhotos.ts";
import { parsePhotoName } from "./parsePhotoName.ts";

function photo(id: string, name: string) {
  const parsed = parsePhotoName(name);
  if (!parsed) throw new Error(`unparsed: ${name}`);
  return { id, parsed };
}

describe("groupPhotos", () => {
  it("merges same title on the same day and keeps the earliest time", () => {
    const groups = groupPhotos([
      photo("b", "2026-10-03 10.00.00__(Judul-Input Pajak bulan Juli)"),
      photo("a", "2026-10-03 08.15.32__(Judul-input pajak  bulan juli)"),
    ]);
    expect(groups).toHaveLength(1);
    expect(groups[0].jam).toBe("08.15.32");
    expect(groups[0].judul).toBe("input pajak bulan juli");
    expect(groups[0].fileIds).toEqual(["b", "a"]);
  });

  it("keeps different days and different titles separate, sorted by time", () => {
    const groups = groupPhotos([
      photo("1", "20261027_115052_Jalan Soekarno Hatta_Judul-routing gaji ASN"),
      photo("2", "2026-10-03 08.15.32__(Judul-routing gaji ASN)"),
      photo("3", "2026-10-03 09.00.00__(Judul-input pajak)"),
    ]);
    expect(groups.map((g) => g.fileIds[0])).toEqual(["2", "3", "1"]);
  });
});
