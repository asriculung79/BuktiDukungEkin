import { describe, expect, it } from "vitest";
import { matchRhk } from "./matchRhk.ts";

const RHK = [
  { _id: "r2", nomor: 2, kataKunci: ["routing"] },
  { _id: "r1", nomor: 1, kataKunci: ["pajak", "spt tahunan"] },
];

describe("matchRhk", () => {
  it("matches keywords case-insensitively", () => {
    expect(matchRhk("Input PAJAK bulan Juli", RHK)?._id).toBe("r1");
    expect(matchRhk("routing gaji ASN", RHK)?._id).toBe("r2");
  });

  it("normalizes spacing in multi-word keywords", () => {
    expect(matchRhk("Lapor SPT   Tahunan", RHK)?._id).toBe("r1");
  });

  it("prefers the lowest RHK number when several match", () => {
    expect(matchRhk("routing pajak", RHK)?._id).toBe("r1");
  });

  it("returns null when nothing matches", () => {
    expect(matchRhk("rapat koordinasi", RHK)).toBeNull();
  });
});
