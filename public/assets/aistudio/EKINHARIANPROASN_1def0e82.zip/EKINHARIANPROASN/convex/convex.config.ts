import { defineApp } from "convex/server";
import { v } from "convex/values";

const app = defineApp({
  env: {
    HERCULES_OIDC_AUTHORITY: v.string(),
    HERCULES_OIDC_CLIENT_ID: v.string(),
    HERCULES_API_KEY: v.string(),
    // Google OAuth app credentials, set by the user in the Secrets tab
    GOOGLE_CLIENT_ID: v.optional(v.string()),
    GOOGLE_CLIENT_SECRET: v.optional(v.string()),
  },
});

export default app;
