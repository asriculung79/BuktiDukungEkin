import { ConvexError } from "convex/values";
import { env } from "../_generated/server";
import type { ActionCtx } from "../_generated/server";
import { internal } from "../_generated/api";
import type { Doc, Id } from "../_generated/dataModel.d.ts";
import { refreshAccessToken, type GoogleCreds } from "./google.ts";

// Refresh a bit before expiry to avoid races with in-flight requests
const EXPIRY_SKEW_MS = 60 * 1000;

export function getCreds(): GoogleCreds {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) {
    throw new ConvexError({
      code: "BAD_REQUEST",
      message: "GOOGLE_CLIENT_ID dan GOOGLE_CLIENT_SECRET belum diisi di tab Secrets",
    });
  }
  return { clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET };
}

export async function currentUserId(ctx: ActionCtx): Promise<Id<"users">> {
  return await ctx.runQuery(internal.drive.connection.currentUserId, {});
}

export function expiresAt(seconds: number): string {
  return new Date(Date.now() + seconds * 1000).toISOString();
}

// Returns a valid access token for the user, refreshing it if needed
export async function getAccessToken(
  ctx: ActionCtx,
  userId: Id<"users">,
): Promise<{ token: string; conn: Doc<"driveConnections"> }> {
  const conn = await ctx.runQuery(internal.drive.connection.getConnection, { userId });
  if (!conn) throw new ConvexError({ code: "NOT_FOUND", message: "Google Drive belum terhubung" });
  if (new Date(conn.accessTokenExpiresAt).getTime() - EXPIRY_SKEW_MS > Date.now()) {
    return { token: conn.accessToken, conn };
  }
  const refreshed = await refreshAccessToken(getCreds(), conn.refreshToken);
  await ctx.runMutation(internal.drive.connection.updateAccessToken, {
    id: conn._id,
    accessToken: refreshed.access_token,
    accessTokenExpiresAt: expiresAt(refreshed.expires_in),
  });
  return { token: refreshed.access_token, conn };
}
