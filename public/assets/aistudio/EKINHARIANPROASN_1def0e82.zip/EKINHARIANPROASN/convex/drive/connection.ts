import { ConvexError, v } from "convex/values";
import { env, internalMutation, internalQuery, mutation, query } from "../_generated/server";
import { requireUser } from "../lib/auth.ts";

const STATE_TTL_MS = 10 * 60 * 1000;

export const status = query({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    const conn = await ctx.db
      .query("driveConnections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .unique();
    return {
      configured: Boolean(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET),
      connection: conn
        ? { googleEmail: conn.googleEmail, rawFolderId: conn.rawFolderId ?? null, rawFolderName: conn.rawFolderName ?? null }
        : null,
    };
  },
});

export const selectFolder = mutation({
  args: { folderId: v.string(), folderName: v.string() },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const conn = await ctx.db
      .query("driveConnections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .unique();
    if (!conn) throw new ConvexError({ code: "NOT_FOUND", message: "Google Drive belum terhubung" });
    await ctx.db.patch("driveConnections", conn._id, { rawFolderId: args.folderId, rawFolderName: args.folderName });
    return null;
  },
});

// ---- Internal helpers used by actions ----

export const currentUserId = internalQuery({
  args: {},
  handler: async (ctx) => (await requireUser(ctx))._id,
});

export const createState = internalMutation({
  args: { userId: v.id("users"), state: v.string() },
  handler: async (ctx, args) => {
    await ctx.db.insert("oauthStates", {
      ...args,
      expiresAt: new Date(Date.now() + STATE_TTL_MS).toISOString(),
    });
    return null;
  },
});

export const consumeState = internalMutation({
  args: { state: v.string() },
  handler: async (ctx, { state }) => {
    const row = await ctx.db
      .query("oauthStates")
      .withIndex("by_state", (q) => q.eq("state", state))
      .unique();
    if (!row) return null;
    await ctx.db.delete("oauthStates", row._id);
    return row.expiresAt > new Date().toISOString() ? row.userId : null;
  },
});

export const getConnection = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) =>
    await ctx.db
      .query("driveConnections")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique(),
});

export const saveConnection = internalMutation({
  args: {
    userId: v.id("users"),
    googleEmail: v.string(),
    refreshToken: v.string(),
    accessToken: v.string(),
    accessTokenExpiresAt: v.string(),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("driveConnections")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();
    if (existing) {
      // Keep the chosen folder only if the same Google account reconnects
      const sameAccount = existing.googleEmail === args.googleEmail;
      await ctx.db.replace("driveConnections", existing._id, {
        ...args,
        rawFolderId: sameAccount ? existing.rawFolderId : undefined,
        rawFolderName: sameAccount ? existing.rawFolderName : undefined,
      });
    } else {
      await ctx.db.insert("driveConnections", args);
    }
    return null;
  },
});

export const updateAccessToken = internalMutation({
  args: { id: v.id("driveConnections"), accessToken: v.string(), accessTokenExpiresAt: v.string() },
  handler: async (ctx, { id, ...rest }) => {
    await ctx.db.patch("driveConnections", id, rest);
    return null;
  },
});

export const deleteConnection = internalMutation({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) => {
    const conn = await ctx.db
      .query("driveConnections")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
    if (conn) await ctx.db.delete("driveConnections", conn._id);
    return null;
  },
});
