import { ConvexError, v } from "convex/values";
import { action } from "../_generated/server";
import { internal } from "../_generated/api";
import { DRIVE_SCOPE, driveGet, exchangeAuthCode, q, revokeToken } from "./google.ts";
import { currentUserId, expiresAt, getAccessToken, getCreds } from "./token.ts";
import { parsePhotoName, type ParsedPhotoName } from "../lib/parsePhotoName.ts";

export const getAuthUrl = action({
  args: { redirectUri: v.string() },
  handler: async (ctx, { redirectUri }): Promise<string> => {
    const creds = getCreds();
    const userId = await currentUserId(ctx);
    const state = crypto.randomUUID();
    await ctx.runMutation(internal.drive.connection.createState, { userId, state });
    const params = new URLSearchParams({
      client_id: creds.clientId,
      redirect_uri: redirectUri,
      response_type: "code",
      scope: DRIVE_SCOPE,
      access_type: "offline",
      // Force consent so Google always returns a refresh token
      prompt: "consent",
      include_granted_scopes: "true",
      state,
    });
    return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  },
});

export const finishConnect = action({
  args: { code: v.string(), state: v.string(), redirectUri: v.string() },
  handler: async (ctx, args): Promise<string> => {
    const creds = getCreds();
    const userId = await currentUserId(ctx);
    const stateUser = await ctx.runMutation(internal.drive.connection.consumeState, { state: args.state });
    if (stateUser !== userId) {
      throw new ConvexError({ code: "FORBIDDEN", message: "Sesi koneksi tidak valid atau kedaluwarsa. Silakan coba lagi." });
    }
    const tokens = await exchangeAuthCode(creds, args.code, args.redirectUri);
    if (!tokens.refresh_token) {
      throw new ConvexError({ code: "EXTERNAL_SERVICE_ERROR", message: "Google tidak memberikan izin akses jangka panjang. Silakan coba lagi." });
    }
    const about = await driveGet<{ user?: { emailAddress?: string } }>(tokens.access_token, "/about", {
      fields: "user(emailAddress)",
    });
    const googleEmail = about.user?.emailAddress ?? "Akun Google";
    await ctx.runMutation(internal.drive.connection.saveConnection, {
      userId,
      googleEmail,
      refreshToken: tokens.refresh_token,
      accessToken: tokens.access_token,
      accessTokenExpiresAt: expiresAt(tokens.expires_in),
    });
    return googleEmail;
  },
});

export const disconnect = action({
  args: {},
  handler: async (ctx): Promise<null> => {
    const userId = await currentUserId(ctx);
    const conn = await ctx.runQuery(internal.drive.connection.getConnection, { userId });
    if (conn) await revokeToken(conn.refreshToken);
    await ctx.runMutation(internal.drive.connection.deleteConnection, { userId });
    return null;
  },
});

export type DriveFolder = { id: string; name: string };

export const listFolders = action({
  args: { parentId: v.optional(v.string()), search: v.optional(v.string()) },
  handler: async (ctx, args): Promise<DriveFolder[]> => {
    const userId = await currentUserId(ctx);
    const { token } = await getAccessToken(ctx, userId);
    const conditions = ["mimeType = 'application/vnd.google-apps.folder'", "trashed = false"];
    const search = args.search?.trim();
    if (search) conditions.push(`name contains '${q(search)}'`);
    else conditions.push(`'${q(args.parentId ?? "root")}' in parents`);
    const res = await driveGet<{ files: DriveFolder[] }>(token, "/files", {
      q: conditions.join(" and "),
      fields: "files(id,name)",
      orderBy: "name",
      pageSize: "100",
    });
    return res.files;
  },
});

export type DrivePhoto = {
  id: string;
  name: string;
  thumbnailLink: string | null;
  parsed: ParsedPhotoName | null;
};

export const listPhotos = action({
  args: { pageToken: v.optional(v.string()) },
  handler: async (ctx, args): Promise<{ photos: DrivePhoto[]; nextPageToken: string | null }> => {
    const userId = await currentUserId(ctx);
    const { token, conn } = await getAccessToken(ctx, userId);
    if (!conn.rawFolderId) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Pilih folder data mentah terlebih dahulu" });
    }
    const params: Record<string, string> = {
      q: `'${q(conn.rawFolderId)}' in parents and mimeType contains 'image/' and trashed = false`,
      fields: "nextPageToken,files(id,name,thumbnailLink)",
      orderBy: "name",
      pageSize: "100",
    };
    if (args.pageToken) params.pageToken = args.pageToken;
    const res = await driveGet<{
      files: { id: string; name: string; thumbnailLink?: string }[];
      nextPageToken?: string;
    }>(token, "/files", params);
    return {
      photos: res.files.map((f) => ({
        id: f.id,
        name: f.name,
        thumbnailLink: f.thumbnailLink ?? null,
        parsed: parsePhotoName(f.name),
      })),
      nextPageToken: res.nextPageToken ?? null,
    };
  },
});
