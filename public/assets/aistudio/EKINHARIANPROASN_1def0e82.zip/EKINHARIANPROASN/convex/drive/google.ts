import { ConvexError } from "convex/values";

// Plain helpers for Google OAuth + Drive REST API (V8 runtime, uses fetch)

export const DRIVE_SCOPE = "https://www.googleapis.com/auth/drive";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const DRIVE_API = "https://www.googleapis.com/drive/v3";

export type GoogleCreds = { clientId: string; clientSecret: string };

export type TokenResponse = {
  access_token: string;
  expires_in: number;
  refresh_token?: string;
};

function externalError(message: string): ConvexError<{ code: string; message: string }> {
  return new ConvexError({ code: "EXTERNAL_SERVICE_ERROR", message });
}

async function readGoogleError(res: Response): Promise<string> {
  const text = await res.text();
  try {
    const json: unknown = JSON.parse(text);
    if (json && typeof json === "object") {
      const obj = json as { error?: unknown; error_description?: unknown };
      if (typeof obj.error_description === "string") return obj.error_description;
      if (obj.error && typeof obj.error === "object" && "message" in obj.error) {
        return String((obj.error as { message: unknown }).message);
      }
      if (typeof obj.error === "string") return obj.error;
    }
  } catch {
    // not JSON
  }
  return text.slice(0, 200) || `HTTP ${res.status}`;
}

async function postToken(params: Record<string, string>): Promise<TokenResponse> {
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(params).toString(),
  });
  if (!res.ok) {
    const msg = await readGoogleError(res);
    if (msg.includes("invalid_grant") || msg.toLowerCase().includes("expired or revoked")) {
      throw externalError("Koneksi Google kedaluwarsa. Silakan putuskan lalu hubungkan ulang Google Drive.");
    }
    throw externalError(`Google menolak permintaan: ${msg}`);
  }
  return (await res.json()) as TokenResponse;
}

export function exchangeAuthCode(creds: GoogleCreds, code: string, redirectUri: string) {
  return postToken({
    code,
    client_id: creds.clientId,
    client_secret: creds.clientSecret,
    redirect_uri: redirectUri,
    grant_type: "authorization_code",
  });
}

export function refreshAccessToken(creds: GoogleCreds, refreshToken: string) {
  return postToken({
    refresh_token: refreshToken,
    client_id: creds.clientId,
    client_secret: creds.clientSecret,
    grant_type: "refresh_token",
  });
}

export async function revokeToken(token: string): Promise<void> {
  // Best effort: ignore failures, the local connection is removed anyway
  await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(token)}`, {
    method: "POST",
  }).catch(() => undefined);
}

export async function driveRequest<T>(
  accessToken: string,
  method: "GET" | "POST" | "PATCH",
  path: string,
  params: Record<string, string>,
  body?: Record<string, unknown>,
): Promise<T> {
  const url = `${DRIVE_API}${path}?${new URLSearchParams(params).toString()}`;
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      ...(body ? { "Content-Type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    throw externalError(`Google Drive error: ${await readGoogleError(res)}`);
  }
  return (await res.json()) as T;
}

export function driveGet<T>(accessToken: string, path: string, params: Record<string, string>): Promise<T> {
  return driveRequest<T>(accessToken, "GET", path, params);
}

const FOLDER_MIME = "application/vnd.google-apps.folder";

// Finds a folder by exact name under a parent, or creates it
export async function findOrCreateFolder(token: string, name: string, parentId: string): Promise<string> {
  const found = await driveGet<{ files: { id: string }[] }>(token, "/files", {
    q: `name = '${q(name)}' and '${q(parentId)}' in parents and mimeType = '${FOLDER_MIME}' and trashed = false`,
    fields: "files(id)",
    pageSize: "1",
  });
  if (found.files[0]) return found.files[0].id;
  const created = await driveRequest<{ id: string }>(token, "POST", "/files", { fields: "id" }, {
    name,
    mimeType: FOLDER_MIME,
    parents: [parentId],
  });
  return created.id;
}

// Creates a folder, shares it as "anyone with the link can view", returns id + link.
// Files inside inherit the public viewer permission.
export async function createSharedFolder(
  token: string,
  name: string,
  parentId: string,
): Promise<{ id: string; link: string }> {
  const folder = await driveRequest<{ id: string; webViewLink?: string }>(
    token,
    "POST",
    "/files",
    { fields: "id,webViewLink" },
    { name, mimeType: FOLDER_MIME, parents: [parentId] },
  );
  await driveRequest(token, "POST", `/files/${folder.id}/permissions`, { fields: "id" }, {
    role: "reader",
    type: "anyone",
  });
  return { id: folder.id, link: folder.webViewLink ?? `https://drive.google.com/drive/folders/${folder.id}` };
}

export async function moveFile(token: string, fileId: string, fromId: string, toId: string): Promise<void> {
  await driveRequest(token, "PATCH", `/files/${fileId}`, {
    addParents: toId,
    removeParents: fromId,
    fields: "id",
  });
}

export async function renameFile(token: string, fileId: string, name: string): Promise<void> {
  await driveRequest(token, "PATCH", `/files/${fileId}`, { fields: "id" }, { name });
}

// Creates a shortcut inside parentId that points to targetId
export async function createShortcut(token: string, name: string, parentId: string, targetId: string): Promise<string> {
  const res = await driveRequest<{ id: string }>(token, "POST", "/files", { fields: "id" }, {
    name,
    mimeType: "application/vnd.google-apps.shortcut",
    parents: [parentId],
    shortcutDetails: { targetId },
  });
  return res.id;
}

// Best effort delete; a file already gone (404) is fine
export async function deleteFile(token: string, fileId: string): Promise<void> {
  const res = await fetch(`${DRIVE_API}/files/${fileId}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok && res.status !== 404) {
    throw externalError(`Google Drive error: ${await readGoogleError(res)}`);
  }
}

// Escape a value for use inside a Drive query string literal
export function q(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
}
