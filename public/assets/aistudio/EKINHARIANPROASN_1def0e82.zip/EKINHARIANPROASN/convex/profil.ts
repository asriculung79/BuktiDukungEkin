import { ConvexError, v } from "convex/values";
import { action, mutation, query } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel.d.ts";
import { requireUser } from "./lib/auth.ts";

const MAX_FOTO_BYTES = 5 * 1024 * 1024;

const EMPTY = {
  namaLengkap: "",
  nip: "",
  pangkat: "",
  jabatan: "",
  atasanNama: "",
  atasanNip: "",
  atasanPangkat: "",
  atasanJabatan: "",
};

const fields = {
  namaLengkap: v.string(),
  nip: v.string(),
  pangkat: v.string(),
  jabatan: v.string(),
  atasanNama: v.string(),
  atasanNip: v.string(),
  atasanPangkat: v.string(),
  atasanJabatan: v.string(),
};

async function findProfil(ctx: MutationCtx, userId: Id<"users">): Promise<Doc<"profilPegawai"> | null> {
  return await ctx.db
    .query("profilPegawai")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .unique();
}

export const get = query({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    const profil = await ctx.db
      .query("profilPegawai")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .unique();
    const fotoUrl = profil?.fotoId ? await ctx.storage.getUrl(profil.fotoId) : null;
    return { ...EMPTY, ...profil, fotoUrl, namaAkun: user.name ?? "" };
  },
});

export const save = mutation({
  args: fields,
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const t = (s: string) => s.trim().slice(0, 200);
    const clean = {
      namaLengkap: t(args.namaLengkap),
      nip: t(args.nip),
      pangkat: t(args.pangkat),
      jabatan: t(args.jabatan),
      atasanNama: t(args.atasanNama),
      atasanNip: t(args.atasanNip),
      atasanPangkat: t(args.atasanPangkat),
      atasanJabatan: t(args.atasanJabatan),
    };
    if (!clean.namaLengkap) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Nama lengkap wajib diisi" });
    }
    const existing = await findProfil(ctx, user._id);
    if (existing) await ctx.db.patch("profilPegawai", existing._id, clean);
    else await ctx.db.insert("profilPegawai", { userId: user._id, ...clean });
    return null;
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireUser(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const setFoto = mutation({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, { storageId }) => {
    const user = await requireUser(ctx);
    const meta = await ctx.db.system.get("_storage", storageId);
    if (!meta || !meta.contentType?.startsWith("image/") || meta.size > MAX_FOTO_BYTES) {
      await ctx.storage.delete(storageId);
      throw new ConvexError({ code: "BAD_REQUEST", message: "File harus berupa gambar maksimal 5 MB" });
    }
    const existing = await findProfil(ctx, user._id);
    if (existing) {
      // Replace: delete the previous file so storage does not pile up
      if (existing.fotoId && existing.fotoId !== storageId) await ctx.storage.delete(existing.fotoId);
      await ctx.db.patch("profilPegawai", existing._id, { fotoId: storageId });
    } else {
      await ctx.db.insert("profilPegawai", {
        userId: user._id,
        ...EMPTY,
        namaLengkap: user.name ?? "",
        fotoId: storageId,
      });
    }
    return null;
  },
});

export const removeFoto = mutation({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    const existing = await findProfil(ctx, user._id);
    if (existing?.fotoId) {
      await ctx.storage.delete(existing.fotoId);
      await ctx.db.patch("profilPegawai", existing._id, { fotoId: undefined });
    }
    return null;
  },
});

// Fetch a public image URL (e.g. copied from MyASN) and store it; client then calls setFoto
export const importFromUrl = action({
  args: { url: v.string() },
  handler: async (ctx, { url }): Promise<Id<"_storage">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ code: "UNAUTHENTICATED", message: "Silakan masuk terlebih dahulu" });
    if (!/^https:\/\//i.test(url.trim())) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "URL harus diawali https://" });
    }
    let res: Response;
    try {
      res = await fetch(url.trim());
    } catch {
      throw new ConvexError({ code: "EXTERNAL_SERVICE_ERROR", message: "Gambar tidak dapat diunduh dari URL tersebut" });
    }
    const type = res.headers.get("content-type") ?? "";
    if (!res.ok || !type.startsWith("image/")) {
      throw new ConvexError({
        code: "BAD_REQUEST",
        message: "URL bukan gambar publik. Jika foto MyASN perlu login, simpan gambarnya lalu unggah manual.",
      });
    }
    const blob = await res.blob();
    if (blob.size > MAX_FOTO_BYTES) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Ukuran gambar maksimal 5 MB" });
    }
    return await ctx.storage.store(blob);
  },
});
