import { ConvexError, v } from "convex/values";
import { internalMutation, internalQuery, mutation, query } from "./_generated/server";
import type { MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";
import { requireUser } from "./lib/auth.ts";

const MAX_RHK = 100;
const MAX_KEYWORDS = 20;

const rhkFields = {
  nomor: v.number(),
  namaRhk: v.string(),
  rencanaAksi: v.string(),
  targetKuantitas: v.number(),
  satuan: v.string(),
  kataKunci: v.array(v.string()),
};

type RhkInput = {
  nomor: number;
  namaRhk: string;
  rencanaAksi: string;
  targetKuantitas: number;
  satuan: string;
  kataKunci: string[];
};

function clean(input: RhkInput): RhkInput {
  const namaRhk = input.namaRhk.trim();
  const rencanaAksi = input.rencanaAksi.trim();
  const satuan = input.satuan.trim();
  if (!namaRhk || !rencanaAksi || !satuan) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Semua kolom wajib diisi" });
  }
  if (!Number.isInteger(input.nomor) || input.nomor < 1) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Nomor RHK tidak valid" });
  }
  if (input.targetKuantitas < 0) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Target tidak boleh negatif" });
  }
  const kataKunci = Array.from(
    new Set(input.kataKunci.map((k) => k.trim().toLowerCase()).filter(Boolean)),
  );
  if (kataKunci.length === 0) {
    throw new ConvexError({ code: "BAD_REQUEST", message: "Isi minimal 1 kata kunci" });
  }
  if (kataKunci.length > MAX_KEYWORDS) {
    throw new ConvexError({ code: "BAD_REQUEST", message: `Maksimal ${MAX_KEYWORDS} kata kunci` });
  }
  return { ...input, namaRhk, rencanaAksi, satuan, kataKunci };
}

async function getOwned(ctx: MutationCtx, id: Id<"rhk">) {
  const user = await requireUser(ctx);
  const doc = await ctx.db.get("rhk", id);
  if (!doc || doc.userId !== user._id) {
    throw new ConvexError({ code: "NOT_FOUND", message: "RHK tidak ditemukan" });
  }
  return doc;
}

export const list = query({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    return await ctx.db
      .query("rhk")
      .withIndex("by_user_and_nomor", (q) => q.eq("userId", user._id))
      .take(MAX_RHK);
  },
});

export const create = mutation({
  args: rhkFields,
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const existing = await ctx.db
      .query("rhk")
      .withIndex("by_user_and_nomor", (q) => q.eq("userId", user._id))
      .take(MAX_RHK);
    if (existing.length >= MAX_RHK) {
      throw new ConvexError({ code: "BAD_REQUEST", message: `Maksimal ${MAX_RHK} RHK` });
    }
    return await ctx.db.insert("rhk", { userId: user._id, ...clean(args) });
  },
});

export const update = mutation({
  args: { id: v.id("rhk"), ...rhkFields },
  handler: async (ctx, { id, ...rest }) => {
    await getOwned(ctx, id);
    await ctx.db.patch("rhk", id, clean(rest));
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("rhk") },
  handler: async (ctx, { id }) => {
    await getOwned(ctx, id);
    await ctx.db.delete("rhk", id);
    return null;
  },
});

// ---- Internal helpers for Drive folder sync ----

export const listForUser = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) =>
    await ctx.db
      .query("rhk")
      .withIndex("by_user_and_nomor", (q) => q.eq("userId", userId))
      .take(MAX_RHK),
});

export const setDriveFolder = internalMutation({
  args: { id: v.id("rhk"), driveFolderId: v.string(), driveFolderName: v.string(), driveLink: v.string() },
  handler: async (ctx, { id, ...fields }) => {
    const doc = await ctx.db.get("rhk", id);
    if (doc) await ctx.db.patch("rhk", id, fields);
    return null;
  },
});
