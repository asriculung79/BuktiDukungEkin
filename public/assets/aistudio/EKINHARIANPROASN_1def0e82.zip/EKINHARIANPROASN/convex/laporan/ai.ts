import { ConvexError, v } from "convex/values";
import { action, internalAction, env } from "../_generated/server";
import { internal } from "../_generated/api";
import { currentUserId } from "../drive/token.ts";

const AI_URL = "https://ai-gateway.hercules.app/v1/chat/completions";

const SYSTEM_PROMPT = `Anda membantu ASN (Aparatur Sipil Negara) Indonesia menulis "Uraian Hasil Kegiatan" untuk laporan e-Kinerja harian.
Tulis 1-2 kalimat formal dalam Bahasa Indonesia baku yang menjelaskan hasil/output nyata dari kegiatan.
Gunakan gaya hasil seperti "Tersusunnya ...", "Terlaksananya ...", atau "Telah dilakukan ... sehingga ...".
Jangan mengarang angka, nama orang, atau fakta yang tidak ada. Jawab hanya dengan uraiannya tanpa tanda kutip.`;

type ChatResponse = { choices?: { message?: { content?: string | null } }[] };

async function askAi(namaKegiatan: string, lokasi: string | undefined): Promise<string> {
  const res = await fetch(AI_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${env.HERCULES_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "openai/gpt-6-luna",
      reasoning_effort: "none",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: `Nama kegiatan: ${namaKegiatan}${lokasi ? `\nLokasi: ${lokasi}` : ""}` },
      ],
    }),
  });
  if (!res.ok) throw new Error(`AI Gateway HTTP ${res.status}`);
  const json = (await res.json()) as ChatResponse;
  return json.choices?.[0]?.message?.content?.trim() ?? "";
}

export const generateUraian = internalAction({
  args: { id: v.id("laporanHarian") },
  handler: async (ctx, { id }): Promise<null> => {
    const row = await ctx.runQuery(internal.laporan.rows.getRow, { id });
    if (!row || row.uraianStatus === "manual") return null;
    try {
      const uraian = await askAi(row.namaKegiatan, row.lokasi);
      await ctx.runMutation(internal.laporan.rows.setUraian, { id, uraian, ok: uraian.length > 0 });
    } catch (e) {
      console.error("generateUraian failed", e);
      await ctx.runMutation(internal.laporan.rows.setUraian, { id, uraian: "", ok: false });
    }
    return null;
  },
});

// User-triggered: ask AI again for one row (also overrides a manual text)
export const regenerate = action({
  args: { id: v.id("laporanHarian") },
  handler: async (ctx, { id }): Promise<null> => {
    const userId = await currentUserId(ctx);
    const ok = await ctx.runMutation(internal.laporan.rows.markPending, { id, userId });
    if (!ok) throw new ConvexError({ code: "NOT_FOUND", message: "Kegiatan tidak ditemukan" });
    await ctx.scheduler.runAfter(0, internal.laporan.ai.generateUraian, { id });
    return null;
  },
});
