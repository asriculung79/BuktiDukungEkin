import { ConvexError, v } from "convex/values";
import { action } from "../_generated/server";
import type { ActionCtx } from "../_generated/server";
import { internal } from "../_generated/api";
import type { Id } from "../_generated/dataModel.d.ts";
import { createSharedFolder, driveGet, findOrCreateFolder, moveFile, q } from "../drive/google.ts";
import { currentUserId, getAccessToken } from "../drive/token.ts";
import { parsePhotoName } from "../lib/parsePhotoName.ts";
import { groupPhotos, type PhotoGroup, type PhotoInput } from "../lib/groupPhotos.ts";

// Bounded per run so one sync stays well inside action time limits; user runs again for the rest
const MAX_PHOTOS_PER_RUN = 150;
const MAX_LIST_PAGES = 10;

export type SyncResult = { dipindah: number; kegiatanBaru: number; dilewati: number; sisa: boolean };

type DriveFile = { id: string; name: string };

async function listRawPhotos(token: string, folderId: string): Promise<{ photos: PhotoInput[]; unparsed: number; more: boolean }> {
  const photos: PhotoInput[] = [];
  let unparsed = 0;
  let pageToken: string | undefined;
  for (let page = 0; page < MAX_LIST_PAGES; page++) {
    const params: Record<string, string> = {
      q: `'${q(folderId)}' in parents and mimeType contains 'image/' and trashed = false`,
      fields: "nextPageToken,files(id,name)",
      orderBy: "name",
      pageSize: "100",
    };
    if (pageToken) params.pageToken = pageToken;
    const res = await driveGet<{ files: DriveFile[]; nextPageToken?: string }>(token, "/files", params);
    for (const f of res.files) {
      const parsed = parsePhotoName(f.name);
      if (!parsed) unparsed++;
      else if (photos.length < MAX_PHOTOS_PER_RUN) photos.push({ id: f.id, parsed });
      else return { photos, unparsed, more: true };
    }
    pageToken = res.nextPageToken;
    if (!pageToken) return { photos, unparsed, more: false };
  }
  return { photos, unparsed, more: true };
}

// "2026-10-03" -> "03-10-2026"
function folderDate(tanggal: string): string {
  const [y, m, d] = tanggal.split("-");
  return `${d}-${m}-${y}`;
}

async function syncGroup(
  ctx: ActionCtx,
  token: string,
  userId: Id<"users">,
  rawFolderId: string,
  dayFolderId: string,
  group: PhotoGroup,
): Promise<boolean> {
  let row = await ctx.runQuery(internal.laporan.rows.getByKey, { userId, kunciGrup: group.kunciGrup });
  let isNew = false;
  if (!row) {
    const folderName = `${group.jam} - ${group.judul}`.slice(0, 200);
    const shared = await createSharedFolder(token, folderName, dayFolderId);
    const id = await ctx.runMutation(internal.laporan.rows.insertRow, {
      userId,
      kunciGrup: group.kunciGrup,
      tanggal: group.tanggal,
      jamKegiatan: group.jam,
      namaKegiatan: group.judul,
      lokasi: group.lokasi ?? undefined,
      driveFolderId: shared.id,
      driveLink: shared.link,
    });
    row = await ctx.runQuery(internal.laporan.rows.getRow, { id });
    isNew = true;
  }
  if (!row) return false;
  for (const fileId of group.fileIds) {
    await moveFile(token, fileId, rawFolderId, row.driveFolderId);
  }
  await ctx.runMutation(internal.laporan.rows.addPhotos, { id: row._id, count: group.fileIds.length, jam: group.jam });
  if (isNew) await ctx.scheduler.runAfter(0, internal.laporan.ai.generateUraian, { id: row._id });
  return isNew;
}

export const syncPhotos = action({
  args: {},
  handler: async (ctx): Promise<SyncResult> => {
    const userId = await currentUserId(ctx);
    const { token, conn } = await getAccessToken(ctx, userId);
    if (!conn.rawFolderId) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Pilih folder data mentah di menu Google Drive terlebih dahulu" });
    }
    const rawFolderId = conn.rawFolderId;
    const { photos, unparsed, more } = await listRawPhotos(token, rawFolderId);
    if (photos.length === 0) return { dipindah: 0, kegiatanBaru: 0, dilewati: unparsed, sisa: false };

    const tanggalRoot = await findOrCreateFolder(token, "TANGGAL", "root");
    const harianRoot = await findOrCreateFolder(token, "HARIAN", tanggalRoot);
    const dayFolders = new Map<string, string>();

    let kegiatanBaru = 0;
    for (const group of groupPhotos(photos)) {
      let dayFolderId = dayFolders.get(group.tanggal);
      if (!dayFolderId) {
        dayFolderId = await findOrCreateFolder(token, folderDate(group.tanggal), harianRoot);
        dayFolders.set(group.tanggal, dayFolderId);
      }
      if (await syncGroup(ctx, token, userId, rawFolderId, dayFolderId, group)) kegiatanBaru++;
    }
    return { dipindah: photos.length, kegiatanBaru, dilewati: unparsed, sisa: more };
  },
});
