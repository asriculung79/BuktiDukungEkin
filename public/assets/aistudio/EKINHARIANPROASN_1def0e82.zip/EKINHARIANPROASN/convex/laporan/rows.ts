import { ConvexError, v } from "convex/values";
import { internalMutation, internalQuery, mutation, query } from "../_generated/server";
import type { MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel.d.ts";
import { requireUser } from "../lib/auth.ts";

const MONTH_RE = /^\d{4}-\d{2}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3])\.[0-5]\d\.[0-5]\d$/;
const MAX_ROWS_PER_MONTH = 1000;
// Most recent activities considered when syncing RHK folders
const MAX_SYNC_ROWS = 2000;

function nextMonth(bulan: string): string {
  const [y, m] = bulan.split("-").map(Number);
  return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, "0")}`;
}

// Rows for one month ("YYYY-MM"), oldest first, as the report table is chronological
export const listByMonth = query({
  args: { bulan: v.string() },
  handler: async (ctx, { bulan }) => {
    if (!MONTH_RE.test(bulan)) throw new ConvexError({ code: "BAD_REQUEST", message: "Format bulan tidak valid" });
    const user = await requireUser(ctx);
    const rows = await ctx.db
      .query("laporanHarian")
      .withIndex("by_user_and_tanggal", (q) =>
        q.eq("userId", user._id).gte("tanggal", `${bulan}-01`).lt("tanggal", `${nextMonth(bulan)}-01`),
      )
      .take(MAX_ROWS_PER_MONTH);
    return rows.sort((a, b) => (a.tanggal + a.jamKegiatan).localeCompare(b.tanggal + b.jamKegiatan));
  },
});

async function getOwnedRow(ctx: MutationCtx, id: Id<"laporanHarian">) {
  const user = await requireUser(ctx);
  const row = await ctx.db.get("laporanHarian", id);
  if (!row || row.userId !== user._id) throw new ConvexError({ code: "NOT_FOUND", message: "Kegiatan tidak ditemukan" });
  return row;
}

export const update = mutation({
  args: {
    id: v.id("laporanHarian"),
    tanggal: v.string(),
    jamKegiatan: v.string(),
    namaKegiatan: v.string(),
    uraian: v.string(),
    driveLink: v.string(),
  },
  handler: async (ctx, { id, ...fields }) => {
    const row = await getOwnedRow(ctx, id);
    if (!DATE_RE.test(fields.tanggal)) throw new ConvexError({ code: "BAD_REQUEST", message: "Tanggal tidak valid" });
    if (!TIME_RE.test(fields.jamKegiatan)) throw new ConvexError({ code: "BAD_REQUEST", message: "Jam harus berformat HH.mm.ss" });
    const namaKegiatan = fields.namaKegiatan.trim();
    if (!namaKegiatan) throw new ConvexError({ code: "BAD_REQUEST", message: "Nama kegiatan wajib diisi" });
    const uraian = fields.uraian.trim();
    await ctx.db.patch("laporanHarian", id, {
      ...fields,
      namaKegiatan,
      uraian,
      driveLink: fields.driveLink.trim(),
      // A hand-edited description must never be overwritten by AI
      uraianStatus: uraian !== row.uraian ? "manual" : row.uraianStatus,
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("laporanHarian") },
  handler: async (ctx, { id }) => {
    await getOwnedRow(ctx, id);
    await ctx.db.delete("laporanHarian", id);
    return null;
  },
});

// Marks a row as waiting for AI; returns false if not owned
export const markPending = internalMutation({
  args: { id: v.id("laporanHarian"), userId: v.id("users") },
  handler: async (ctx, { id, userId }) => {
    const row = await ctx.db.get("laporanHarian", id);
    if (!row || row.userId !== userId) return false;
    await ctx.db.patch("laporanHarian", id, { uraianStatus: "pending" });
    return true;
  },
});

// ---- Internal helpers used by the sync + AI actions ----

export const getByKey = internalQuery({
  args: { userId: v.id("users"), kunciGrup: v.string() },
  handler: async (ctx, args) =>
    await ctx.db
      .query("laporanHarian")
      .withIndex("by_user_and_kunciGrup", (q) => q.eq("userId", args.userId).eq("kunciGrup", args.kunciGrup))
      .first(),
});

export const getRow = internalQuery({
  args: { id: v.id("laporanHarian") },
  handler: async (ctx, { id }) => await ctx.db.get("laporanHarian", id),
});

export const insertRow = internalMutation({
  args: {
    userId: v.id("users"),
    kunciGrup: v.string(),
    tanggal: v.string(),
    jamKegiatan: v.string(),
    namaKegiatan: v.string(),
    lokasi: v.optional(v.string()),
    driveFolderId: v.string(),
    driveLink: v.string(),
  },
  handler: async (ctx, args) =>
    await ctx.db.insert("laporanHarian", { ...args, uraian: "", uraianStatus: "pending", jumlahFoto: 0 }),
});

export const addPhotos = internalMutation({
  args: { id: v.id("laporanHarian"), count: v.number(), jam: v.string() },
  handler: async (ctx, { id, count, jam }) => {
    const row = await ctx.db.get("laporanHarian", id);
    if (!row) return null;
    // Keep the earliest time only while the grouping date is unchanged by the user
    const keepEarliest = row.kunciGrup.startsWith(row.tanggal) && jam < row.jamKegiatan;
    await ctx.db.patch("laporanHarian", id, {
      jumlahFoto: row.jumlahFoto + count,
      ...(keepEarliest ? { jamKegiatan: jam } : {}),
    });
    return null;
  },
});

export const listForUser = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, { userId }) =>
    await ctx.db
      .query("laporanHarian")
      .withIndex("by_user_and_tanggal", (q) => q.eq("userId", userId))
      .order("desc")
      .take(MAX_SYNC_ROWS),
});

export const setShortcut = internalMutation({
  args: { id: v.id("laporanHarian"), rhkShortcutRhkId: v.optional(v.id("rhk")), rhkShortcutId: v.optional(v.string()) },
  handler: async (ctx, { id, ...fields }) => {
    const row = await ctx.db.get("laporanHarian", id);
    if (row) await ctx.db.patch("laporanHarian", id, fields);
    return null;
  },
});

export const setUraian = internalMutation({
  args: { id: v.id("laporanHarian"), uraian: v.string(), ok: v.boolean() },
  handler: async (ctx, { id, uraian, ok }) => {
    const row = await ctx.db.get("laporanHarian", id);
    // Never overwrite a description the user typed while AI was running
    if (!row || row.uraianStatus === "manual") return null;
    await ctx.db.patch("laporanHarian", id, ok ? { uraian, uraianStatus: "ai" } : { uraianStatus: "error" });
    return null;
  },
});
