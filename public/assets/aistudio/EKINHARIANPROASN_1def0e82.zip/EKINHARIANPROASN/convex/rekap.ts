import { ConvexError, v } from "convex/values";
import { action, query } from "./_generated/server";
import type { ActionCtx } from "./_generated/server";
import { internal } from "./_generated/api";
import type { Doc } from "./_generated/dataModel.d.ts";
import { requireUser } from "./lib/auth.ts";
import { matchRhk } from "./lib/matchRhk.ts";
import { createSharedFolder, createShortcut, deleteFile, findOrCreateFolder, renameFile } from "./drive/google.ts";
import { currentUserId, getAccessToken } from "./drive/token.ts";

const MAX_ROWS_PER_YEAR = 3000;
const MAX_RHK = 100;
// Shortcut changes per run, keeps one sync well within action time limits
const MAX_SHORTCUT_OPS = 120;

export type RekapKegiatan = { _id: string; tanggal: string; jamKegiatan: string; namaKegiatan: string; driveLink: string; jumlahFoto: number };

// Realization per RHK for one year ("YYYY"), mapped live by keyword so edits to titles or keywords apply instantly
export const byYear = query({
  args: { tahun: v.string() },
  handler: async (ctx, { tahun }) => {
    if (!/^\d{4}$/.test(tahun)) throw new ConvexError({ code: "BAD_REQUEST", message: "Tahun tidak valid" });
    const user = await requireUser(ctx);
    const rhkList = await ctx.db
      .query("rhk")
      .withIndex("by_user_and_nomor", (q) => q.eq("userId", user._id))
      .take(MAX_RHK);
    const rows = await ctx.db
      .query("laporanHarian")
      .withIndex("by_user_and_tanggal", (q) =>
        q.eq("userId", user._id).gte("tanggal", `${tahun}-01-01`).lt("tanggal", `${Number(tahun) + 1}-01-01`),
      )
      .take(MAX_ROWS_PER_YEAR);

    const buckets = new Map<string, RekapKegiatan[]>(rhkList.map((r) => [r._id, []]));
    let tanpaRhk = 0;
    for (const row of rows) {
      const match = matchRhk(row.namaKegiatan, rhkList);
      const item = {
        _id: row._id,
        tanggal: row.tanggal,
        jamKegiatan: row.jamKegiatan,
        namaKegiatan: row.namaKegiatan,
        driveLink: row.driveLink,
        jumlahFoto: row.jumlahFoto,
      };
      if (match) buckets.get(match._id)?.push(item);
      else tanpaRhk++;
    }

    return {
      totalKegiatan: rows.length,
      tanpaRhk,
      rhk: rhkList.map((r) => {
        const kegiatan = (buckets.get(r._id) ?? []).sort((a, b) => (b.tanggal + b.jamKegiatan).localeCompare(a.tanggal + a.jamKegiatan));
        return {
          _id: r._id,
          nomor: r.nomor,
          namaRhk: r.namaRhk,
          rencanaAksi: r.rencanaAksi,
          targetKuantitas: r.targetKuantitas,
          satuan: r.satuan,
          kataKunci: r.kataKunci,
          driveLink: r.driveLink ?? null,
          realisasi: kegiatan.length,
          jumlahFoto: kegiatan.reduce((s, k) => s + k.jumlahFoto, 0),
          kegiatan: kegiatan.slice(0, 50),
        };
      }),
    };
  },
});

function folderName(rhk: Doc<"rhk">): string {
  return `RHK ${rhk.nomor}, ${rhk.namaRhk}`.slice(0, 200);
}

// Ensures every RHK has a public folder under "RHK RENCANA AKSI" with an up-to-date name
async function syncRhkFolders(ctx: ActionCtx, token: string, rhkList: Doc<"rhk">[]): Promise<Map<string, string>> {
  const folders = new Map<string, string>();
  const missing = rhkList.filter((r) => !r.driveFolderId);
  const rootId = missing.length > 0 ? await findOrCreateFolder(token, "RHK RENCANA AKSI", "root") : null;
  for (const rhk of rhkList) {
    const name = folderName(rhk);
    if (rhk.driveFolderId) {
      if (rhk.driveFolderName !== name) {
        await renameFile(token, rhk.driveFolderId, name);
        await ctx.runMutation(internal.rhk.setDriveFolder, {
          id: rhk._id, driveFolderId: rhk.driveFolderId, driveFolderName: name, driveLink: rhk.driveLink ?? "",
        });
      }
      folders.set(rhk._id, rhk.driveFolderId);
    } else if (rootId) {
      const shared = await createSharedFolder(token, name, rootId);
      await ctx.runMutation(internal.rhk.setDriveFolder, {
        id: rhk._id, driveFolderId: shared.id, driveFolderName: name, driveLink: shared.link,
      });
      folders.set(rhk._id, shared.id);
    }
  }
  return folders;
}

export type RekapSyncResult = { folderRhk: number; dipetakan: number; sisa: boolean };

// Creates RHK folders and places a shortcut to each matched activity folder inside its RHK folder
export const syncDrive = action({
  args: {},
  handler: async (ctx): Promise<RekapSyncResult> => {
    const userId = await currentUserId(ctx);
    const { token } = await getAccessToken(ctx, userId);
    const rhkList = await ctx.runQuery(internal.rhk.listForUser, { userId });
    if (rhkList.length === 0) {
      throw new ConvexError({ code: "BAD_REQUEST", message: "Tambahkan RHK terlebih dahulu di menu Data RHK" });
    }
    const folders = await syncRhkFolders(ctx, token, rhkList);
    const rows = await ctx.runQuery(internal.laporan.rows.listForUser, { userId });

    let ops = 0;
    let dipetakan = 0;
    for (const row of rows) {
      const match = matchRhk(row.namaKegiatan, rhkList);
      const targetRhkId = match?._id;
      if (targetRhkId === row.rhkShortcutRhkId && (!targetRhkId || row.rhkShortcutId)) continue;
      if (ops >= MAX_SHORTCUT_OPS) return { folderRhk: folders.size, dipetakan, sisa: true };
      ops++;
      if (row.rhkShortcutId) await deleteFile(token, row.rhkShortcutId);
      const folderId = targetRhkId ? folders.get(targetRhkId) : undefined;
      const shortcutId = folderId
        ? await createShortcut(token, `${row.tanggal} ${row.jamKegiatan} - ${row.namaKegiatan}`.slice(0, 200), folderId, row.driveFolderId)
        : undefined;
      await ctx.runMutation(internal.laporan.rows.setShortcut, {
        id: row._id,
        rhkShortcutRhkId: shortcutId ? targetRhkId : undefined,
        rhkShortcutId: shortcutId,
      });
      if (shortcutId) dipetakan++;
    }
    return { folderRhk: folders.size, dipetakan, sisa: false };
  },
});
