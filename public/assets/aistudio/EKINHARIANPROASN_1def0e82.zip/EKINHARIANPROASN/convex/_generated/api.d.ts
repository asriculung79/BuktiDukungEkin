/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as drive_actions from "../drive/actions.js";
import type * as drive_connection from "../drive/connection.js";
import type * as drive_google from "../drive/google.js";
import type * as drive_token from "../drive/token.js";
import type * as laporan_ai from "../laporan/ai.js";
import type * as laporan_rows from "../laporan/rows.js";
import type * as laporan_sync from "../laporan/sync.js";
import type * as lib_auth from "../lib/auth.js";
import type * as lib_groupPhotos from "../lib/groupPhotos.js";
import type * as lib_matchRhk from "../lib/matchRhk.js";
import type * as lib_parsePhotoName from "../lib/parsePhotoName.js";
import type * as profil from "../profil.js";
import type * as rekap from "../rekap.js";
import type * as rhk from "../rhk.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  "drive/actions": typeof drive_actions;
  "drive/connection": typeof drive_connection;
  "drive/google": typeof drive_google;
  "drive/token": typeof drive_token;
  "laporan/ai": typeof laporan_ai;
  "laporan/rows": typeof laporan_rows;
  "laporan/sync": typeof laporan_sync;
  "lib/auth": typeof lib_auth;
  "lib/groupPhotos": typeof lib_groupPhotos;
  "lib/matchRhk": typeof lib_matchRhk;
  "lib/parsePhotoName": typeof lib_parsePhotoName;
  profil: typeof profil;
  rekap: typeof rekap;
  rhk: typeof rhk;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
