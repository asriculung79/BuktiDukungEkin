import { useEffect, useRef, useState } from "react";
import { useAction, useMutation } from "convex/react";
import { Camera, ChevronDown, CircleHelp, ExternalLink, Link2, Trash2, Upload, Zap } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible.tsx";
import { useCamera } from "@/hooks/use-camera.ts";
import ProfilAvatar from "./profil-avatar.tsx";
import { errorMessage, useUploadFoto } from "./use-upload-foto.ts";

type Props = { hasFoto: boolean; name: string };

const MYASN_URL = "https://myasn.bkn.go.id";

function CameraPanel({ onDone }: { onDone: () => void }) {
  const { videoRef, active, isLoading, error, capture, start, stop } = useCamera();
  const upload = useUploadFoto();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void start();
    return stop;
  }, [start, stop]);

  const take = async () => {
    const blob = await capture();
    if (!blob) return;
    setBusy(true);
    const ok = await upload(blob);
    setBusy(false);
    if (ok) onDone();
  };

  return (
    <div className="space-y-3 pt-4">
      <div className="relative mx-auto aspect-[3/4] w-48 overflow-hidden rounded-lg bg-black">
        <video ref={videoRef} autoPlay playsInline muted className="size-full -scale-x-100 object-cover" />
        {isLoading && <div className="absolute inset-0 flex items-center justify-center"><Spinner className="text-white" /></div>}
      </div>
      {error && <p className="text-center text-sm text-destructive">{error}</p>}
      <div className="flex justify-center gap-2">
        <Button type="button" variant="ghost" size="sm" onClick={onDone}>Tutup kamera</Button>
        <Button type="button" size="sm" onClick={take} disabled={!active || busy}>
          {busy ? <Spinner /> : <Camera className="size-4" />} Ambil foto
        </Button>
      </div>
    </div>
  );
}

export default function FotoSection({ hasFoto, name }: Props) {
  const upload = useUploadFoto();
  const importFromUrl = useAction(api.profil.importFromUrl);
  const setFoto = useMutation(api.profil.setFoto);
  const removeFoto = useMutation(api.profil.removeFoto);
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState("");
  const [cameraOpen, setCameraOpen] = useState(false);

  const run = async (task: () => Promise<unknown>) => {
    setBusy(true);
    try {
      await task();
    } finally {
      setBusy(false);
    }
  };

  // Ctrl+V anywhere in the dialog: paste a copied image directly
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const item = Array.from(e.clipboardData?.items ?? []).find((i) => i.type.startsWith("image/"));
      const file = item?.getAsFile();
      if (!file) return;
      e.preventDefault();
      void run(() => upload(file));
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [upload]);

  const applyUrl = () =>
    run(async () => {
      try {
        const storageId = await importFromUrl({ url });
        await setFoto({ storageId });
        setUrl("");
        toast.success("Foto profil diperbarui");
      } catch (error) {
        toast.error(errorMessage(error, "Gagal mengambil foto dari URL"));
      }
    });

  return (
    <section className="rounded-xl border bg-muted/40 p-4">
      <h3 className="flex items-center gap-2 text-sm font-semibold text-primary dark:text-accent">
        <Camera className="size-4" /> Foto Profil Resmi ASN (Menu & Navigasi)
      </h3>
      <div className="flex flex-col gap-4 pt-4 sm:flex-row sm:items-center">
        <ProfilAvatar className="size-24 text-3xl ring-2 ring-accent/50" nameFallback={name} />
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            {hasFoto
              ? "Foto resmi Anda tampil di menu dan navigasi."
              : "Saat ini menu menampilkan inisial nama. Unggah Pas Foto ASN (seragam/batik/formal) agar tampil secara resmi."}
          </p>
          <div className="flex flex-wrap gap-2">
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (file) void run(() => upload(file));
              }}
            />
            <Button type="button" size="sm" disabled={busy} onClick={() => fileRef.current?.click()}>
              {busy ? <Spinner /> : <Upload className="size-4" />} Unggah Foto ASN
            </Button>
            <Button type="button" size="sm" variant="secondary" disabled={busy} onClick={() => setCameraOpen((o) => !o)}>
              <Camera className="size-4" /> Kamera
            </Button>
            {hasFoto && (
              <Button type="button" size="sm" variant="ghost" disabled={busy} onClick={() => run(() => removeFoto({}))}>
                <Trash2 className="size-4" /> Hapus
              </Button>
            )}
          </div>
        </div>
      </div>

      {cameraOpen && <CameraPanel onDone={() => setCameraOpen(false)} />}

      <div className="mt-4 border-t pt-4">
        <Collapsible>
          <div className="flex items-center justify-between gap-2">
            <h4 className="flex items-center gap-2 text-sm font-semibold text-primary dark:text-accent">
              <Zap className="size-4" /> Sinkronisasi Foto dari Akun MyASN Digital BKN
            </h4>
            <CollapsibleTrigger className="flex shrink-0 cursor-pointer items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
              <CircleHelp className="size-3.5" /> Cara sinkron <ChevronDown className="size-3.5" />
            </CollapsibleTrigger>
          </div>
          <CollapsibleContent>
            <ol className="list-decimal space-y-1 pt-3 pl-5 text-xs text-muted-foreground">
              <li>Klik "Buka MyASN BKN" dan masuk ke akun Anda.</li>
              <li>Klik kanan foto profil, pilih "Salin gambar" atau "Salin alamat gambar".</li>
              <li>Kembali ke sini, tekan Ctrl + V untuk menempel gambar, atau tempel alamatnya di kolom URL.</li>
            </ol>
          </CollapsibleContent>
        </Collapsible>
        <div className="flex flex-col gap-2 pt-3 sm:flex-row">
          <Button type="button" size="sm" variant="secondary" asChild>
            <a href={MYASN_URL} target="_blank" rel="noreferrer">
              <ExternalLink className="size-4" /> Buka MyASN BKN
            </a>
          </Button>
          <div className="relative flex-1">
            <Link2 className="absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Tempel URL foto MyASN"
              className="h-8 pl-8"
            />
          </div>
          <Button type="button" size="sm" disabled={busy || !url.trim()} onClick={applyUrl}>Terapkan</Button>
        </div>
        <p className="pt-2 text-[11px] text-muted-foreground">
          Dukungan clipboard: tekan <kbd className="font-semibold">Ctrl + V</kbd> di mana saja pada jendela ini untuk menempel foto langsung.
        </p>
      </div>
    </section>
  );
}
