import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

export function errorMessage(error: unknown, fallback: string): string {
  return error instanceof ConvexError ? (error.data as { message: string }).message : fallback;
}

export function initials(name: string): string {
  const parts = name.replace(/,.*$/, "").trim().split(/\s+/).filter(Boolean);
  return (parts[0]?.[0] ?? "A").concat(parts[1]?.[0] ?? "").toUpperCase();
}

// Upload an image blob to Convex storage and set it as the profile photo
export function useUploadFoto() {
  const generateUploadUrl = useMutation(api.profil.generateUploadUrl);
  const setFoto = useMutation(api.profil.setFoto);
  return async (file: Blob): Promise<boolean> => {
    if (!file.type.startsWith("image/")) {
      toast.error("File harus berupa gambar");
      return false;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Ukuran foto maksimal 5 MB");
      return false;
    }
    try {
      const url = await generateUploadUrl();
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": file.type }, body: file });
      if (!res.ok) throw new Error("upload failed");
      const { storageId } = (await res.json()) as { storageId: Id<"_storage"> };
      await setFoto({ storageId });
      toast.success("Foto profil diperbarui");
      return true;
    } catch (error) {
      toast.error(errorMessage(error, "Gagal mengunggah foto"));
      return false;
    }
  };
}
