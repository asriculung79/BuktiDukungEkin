import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { cn } from "@/lib/utils.ts";
import { initials } from "./use-upload-foto.ts";

type Props = { className?: string; nameFallback?: string };

// Pas foto ASN from profile, or gold initials tile when no photo is set
export default function ProfilAvatar({ className, nameFallback = "" }: Props) {
  const profil = useQuery(api.profil.get, {});
  const name = profil?.namaLengkap || profil?.namaAkun || nameFallback;
  return (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center overflow-hidden rounded-lg bg-gradient-to-br from-[oklch(0.85_0.14_85)] to-[oklch(0.7_0.15_65)] font-serif font-bold text-[oklch(0.2_0.05_262)]",
        className,
      )}
    >
      {profil?.fotoUrl ? (
        <img src={profil.fotoUrl} alt={name} className="size-full object-cover" />
      ) : (
        <span>{initials(name)}</span>
      )}
    </div>
  );
}
