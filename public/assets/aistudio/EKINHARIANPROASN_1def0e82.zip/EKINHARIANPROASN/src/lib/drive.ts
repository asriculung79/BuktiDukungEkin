import { ConvexError } from "convex/values";

export const DRIVE_CALLBACK_PATH = "/app/drive/callback";

export function driveRedirectUri(): string {
  return `${window.location.origin}${DRIVE_CALLBACK_PATH}`;
}

export function errorMessage(error: unknown, fallback: string): string {
  if (error instanceof ConvexError) {
    const data = error.data as { message?: string };
    if (data.message) return data.message;
  }
  return fallback;
}

const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

// "2026-10-03" -> { hari: "Sabtu", tanggal: "03-10-2026" }
export function formatTanggal(iso: string): { hari: string; tanggal: string } {
  const [y, m, d] = iso.split("-").map(Number);
  const day = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return { hari: HARI[day], tanggal: `${String(d).padStart(2, "0")}-${String(m).padStart(2, "0")}-${y}` };
}
