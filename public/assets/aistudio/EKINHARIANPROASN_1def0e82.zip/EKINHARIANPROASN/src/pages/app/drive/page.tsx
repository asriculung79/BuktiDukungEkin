import { useState } from "react";
import { useAction, useQuery } from "convex/react";
import { useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, FolderInput, FolderSync, RefreshCcw, Unplug } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { driveRedirectUri, errorMessage } from "@/lib/drive.ts";
import SetupGuide from "./_components/setup-guide.tsx";
import FolderPickerDialog from "./_components/folder-picker-dialog.tsx";
import PhotoList from "./_components/photo-list.tsx";

export default function DrivePage() {
  const status = useQuery(api.drive.connection.status, {});
  const getAuthUrl = useAction(api.drive.actions.getAuthUrl);
  const disconnect = useAction(api.drive.actions.disconnect);
  const queryClient = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);

  const connect = async () => {
    setBusy(true);
    try {
      window.location.href = await getAuthUrl({ redirectUri: driveRedirectUri() });
    } catch (e) {
      toast.error(errorMessage(e, "Gagal memulai koneksi"));
      setBusy(false);
    }
  };

  const handleDisconnect = async () => {
    setBusy(true);
    try {
      await disconnect({});
      toast.success("Google Drive diputuskan");
    } catch (e) {
      toast.error(errorMessage(e, "Gagal memutuskan koneksi"));
    }
    setBusy(false);
  };

  const conn = status?.connection;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-serif text-3xl font-bold">Google Drive</h1>
        <p className="pt-1 text-muted-foreground">Hubungkan akun Google Anda dan pilih folder data mentah foto Timemark.</p>
      </div>

      {status === undefined ? (
        <Skeleton className="h-40 w-full rounded-xl" />
      ) : !status.configured ? (
        <SetupGuide />
      ) : !conn ? (
        <Card className="overflow-hidden py-0">
          <CardContent className="flex flex-col items-start gap-4 bg-[radial-gradient(ellipse_at_top_right,oklch(0.8_0.13_80/0.18),transparent_60%)] p-6 sm:flex-row sm:items-center">
            <div className="flex size-12 items-center justify-center rounded-xl bg-sidebar text-sidebar-primary"><FolderSync className="size-6" /></div>
            <div className="flex-1">
              <div className="font-semibold">Belum terhubung</div>
              <p className="text-sm text-muted-foreground">Masuk dengan akun Google tempat foto bukti dukung Anda disimpan.</p>
            </div>
            <Button onClick={connect} disabled={busy}>{busy && <Spinner />} Hubungkan Google Drive</Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="py-0">
            <CardContent className="grid gap-4 p-5 md:grid-cols-2">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="size-8 shrink-0 text-chart-4" />
                <div className="min-w-0">
                  <div className="text-xs text-muted-foreground">Terhubung sebagai</div>
                  <div className="truncate font-semibold">{conn.googleEmail}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <FolderInput className="size-8 shrink-0 text-accent" />
                <div className="min-w-0">
                  <div className="text-xs text-muted-foreground">Folder data mentah</div>
                  <div className="truncate font-semibold">{conn.rawFolderName ?? "Belum dipilih"}</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 md:col-span-2">
                <Button size="sm" onClick={() => setPickerOpen(true)}><FolderInput className="size-4" /> {conn.rawFolderId ? "Ganti folder" : "Pilih folder"}</Button>
                {conn.rawFolderId && (
                  <Button size="sm" variant="secondary" onClick={() => queryClient.invalidateQueries({ queryKey: ["drivePhotos"] })}>
                    <RefreshCcw className="size-4" /> Muat ulang foto
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={handleDisconnect} disabled={busy}><Unplug className="size-4" /> Putuskan</Button>
              </div>
            </CardContent>
          </Card>
          {conn.rawFolderId && <PhotoList folderId={conn.rawFolderId} />}
          <FolderPickerDialog open={pickerOpen} onOpenChange={setPickerOpen} />
        </>
      )}
    </div>
  );
}
