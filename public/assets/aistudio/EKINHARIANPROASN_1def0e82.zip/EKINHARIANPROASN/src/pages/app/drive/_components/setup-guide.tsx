import { useState } from "react";
import { Check, Copy, ExternalLink, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { driveRedirectUri } from "@/lib/drive.ts";

function CopyBox({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    toast.success("Disalin");
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="flex items-center gap-2 rounded-lg border bg-muted px-3 py-2">
      <code className="min-w-0 flex-1 truncate text-xs">{value}</code>
      <Button size="icon" variant="ghost" className="size-7" onClick={copy} aria-label="Salin">
        {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
      </Button>
    </div>
  );
}

export default function SetupGuide() {
  const steps = [
    <>Buka <a className="font-medium text-primary underline" href="https://console.cloud.google.com/projectcreate" target="_blank" rel="noreferrer">Google Cloud Console</a> dan buat project baru (misal "Cloud Ekin").</>,
    <>Aktifkan <a className="font-medium text-primary underline" href="https://console.cloud.google.com/apis/library/drive.googleapis.com" target="_blank" rel="noreferrer">Google Drive API</a> untuk project tersebut.</>,
    <>Buka <a className="font-medium text-primary underline" href="https://console.cloud.google.com/auth/branding" target="_blank" rel="noreferrer">Google Auth Platform</a>, isi nama aplikasi dan email. Pilih tipe <b>External</b>. Di bagian <b>Audience</b>, tambahkan email pegawai sebagai <b>Test users</b> (atau publikasikan aplikasinya).</>,
    <>Buka <a className="font-medium text-primary underline" href="https://console.cloud.google.com/auth/clients/create" target="_blank" rel="noreferrer">Clients</a>, buat client tipe <b>Web application</b>, lalu tambahkan alamat berikut di <b>Authorized redirect URIs</b>:</>,
    <>Salin <b>Client ID</b> dan <b>Client secret</b>, lalu simpan di Hercules: buka <b>Advanced &gt; Secrets</b>, tambahkan <code>GOOGLE_CLIENT_ID</code> dan <code>GOOGLE_CLIENT_SECRET</code>.</>,
  ];
  return (
    <Card>
      <CardHeader>
        <div className="flex size-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground"><KeyRound className="size-5" /></div>
        <CardTitle className="pt-2">Pengaturan awal Google Drive (sekali saja)</CardTitle>
        <CardDescription>Dilakukan oleh admin aplikasi. Setelah selesai, setiap pegawai cukup klik "Hubungkan Google Drive".</CardDescription>
      </CardHeader>
      <CardContent>
        <ol className="space-y-4">
          {steps.map((s, i) => (
            <li key={i} className="flex gap-3">
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">{i + 1}</span>
              <div className="min-w-0 flex-1 space-y-2 text-sm leading-relaxed">
                <div>{s}</div>
                {i === 3 && <CopyBox value={driveRedirectUri()} />}
              </div>
            </li>
          ))}
        </ol>
        <p className="flex items-center gap-1.5 pt-6 text-xs text-muted-foreground">
          <ExternalLink className="size-3" /> Setelah dipublikasikan, tambahkan juga alamat redirect versi domain publik Anda.
        </p>
      </CardContent>
    </Card>
  );
}
