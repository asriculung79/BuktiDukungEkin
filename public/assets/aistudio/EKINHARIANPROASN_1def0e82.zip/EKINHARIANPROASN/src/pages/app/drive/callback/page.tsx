import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAction } from "convex/react";
import { AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  ErrorState, ErrorStateContent, ErrorStateDescription, ErrorStateHeader, ErrorStateMedia, ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { driveRedirectUri, errorMessage } from "@/lib/drive.ts";

export default function DriveCallbackPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const finishConnect = useAction(api.drive.actions.finishConnect);
  const [error, setError] = useState<string | null>(null);
  const code = params.get("code");
  const state = params.get("state");
  const invalid = Boolean(params.get("error")) || !code || !state;
  // Google codes are single-use; guard against StrictMode double-invocation
  const started = useRef(false);

  useEffect(() => {
    if (started.current || !code || !state || invalid) return;
    started.current = true;
    finishConnect({ code, state, redirectUri: driveRedirectUri() })
      .then((email) => {
        toast.success(`Terhubung ke ${email}`);
        navigate("/app/drive", { replace: true });
      })
      .catch((e: unknown) => setError(errorMessage(e, "Gagal menghubungkan Google Drive.")));
  }, [code, state, invalid, finishConnect, navigate]);

  const shownError = invalid ? "Koneksi dibatalkan atau izin tidak diberikan." : error;

  if (shownError) {
    return (
      <ErrorState className="border">
        <ErrorStateHeader>
          <ErrorStateMedia variant="icon"><AlertTriangle /></ErrorStateMedia>
          <ErrorStateTitle>Gagal menghubungkan</ErrorStateTitle>
          <ErrorStateDescription>{shownError}</ErrorStateDescription>
        </ErrorStateHeader>
        <ErrorStateContent>
          <Button asChild size="sm"><Link to="/app/drive">Kembali</Link></Button>
        </ErrorStateContent>
      </ErrorState>
    );
  }

  return (
    <div className="flex flex-col items-center gap-3 py-24 text-muted-foreground">
      <Spinner className="size-8" />
      Menghubungkan Google Drive...
    </div>
  );
}
