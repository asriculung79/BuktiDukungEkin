import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { Authenticated, AuthLoading, Unauthenticated, useQuery } from "convex/react";
import { CalendarDays, FolderSync, LayoutDashboard, Target, Trophy, UserCog } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { cn } from "@/lib/utils.ts";
import { Button } from "@/components/ui/button.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import BrandLogo from "@/components/brand-logo.tsx";
import ProfilAvatar from "@/components/profil/profil-avatar.tsx";
import ProfilDialog from "@/components/profil/profil-dialog.tsx";

const NAV = [
  { label: "Dashboard", short: "Beranda", icon: LayoutDashboard, to: "/app" },
  { label: "Data RHK & Rencana Aksi", short: "RHK", icon: Target, to: "/app/rhk" },
  { label: "Google Drive", short: "Drive", icon: FolderSync, to: "/app/drive" },
  { label: "Laporan Harian", short: "Harian", icon: CalendarDays, to: "/app/laporan" },
  { label: "Rekap Realisasi", short: "Rekap", icon: Trophy, to: "/app/rekap" },
];

function SideNav() {
  return (
    <nav className="flex flex-col gap-1">
      {NAV.map((item) => (
        <NavLink
          key={item.label}
          to={item.to}
          end
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors",
              isActive
                ? "bg-sidebar-accent font-semibold text-sidebar-primary"
                : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
            )
          }
        >
          <item.icon className="size-4" /> {item.label}
        </NavLink>
      ))}
    </nav>
  );
}

function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-sidebar-border bg-sidebar py-1.5 md:hidden">
      {NAV.map((item) => (
        <NavLink key={item.label} to={item.to} end>
          {({ isActive }) => (
            <span className={cn("flex flex-col items-center gap-0.5 px-2 py-1 text-[11px]", isActive ? "text-sidebar-primary" : "text-sidebar-foreground/60")}>
              <item.icon className="size-5" /> {item.short}
            </span>
          )}
        </NavLink>
      ))}
    </nav>
  );
}

function UserBox({ onOpenProfil }: { onOpenProfil: () => void }) {
  const { user } = useAuth();
  const profil = useQuery(api.profil.get, {});
  const nama = profil?.namaLengkap || user?.profile.name || "Pegawai ASN";
  return (
    <div className="space-y-3 rounded-xl border border-sidebar-border bg-sidebar-accent/40 p-3">
      <button type="button" onClick={onOpenProfil} className="flex w-full min-w-0 cursor-pointer items-center gap-3 rounded-lg text-left">
        <ProfilAvatar className="size-11 text-base" nameFallback={nama} />
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold text-sidebar-foreground">{nama}</div>
          <div className="truncate text-xs text-sidebar-foreground/60">{profil?.jabatan || user?.profile.email}</div>
        </div>
      </button>
      <div className="grid grid-cols-2 gap-2">
        <Button size="sm" variant="secondary" onClick={onOpenProfil}>
          <UserCog className="size-4" /> Profil
        </Button>
        <SignInButton size="sm" variant="secondary" signOutText="Keluar" />
      </div>
    </div>
  );
}

export default function AppLayout() {
  const [profilOpen, setProfilOpen] = useState(false);
  const openProfil = () => setProfilOpen(true);
  return (
    <>
      <AuthLoading>
        <div className="space-y-4 p-8">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-40 w-full" />
        </div>
      </AuthLoading>
      <Unauthenticated>
        <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background p-6 text-center">
          <BrandLogo />
          <p className="max-w-sm text-muted-foreground">Silakan masuk untuk mengelola data kinerja Anda.</p>
          <SignInButton signInText="Masuk" />
        </div>
      </Unauthenticated>
      <Authenticated>
        <div className="flex min-h-screen bg-background">
          <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col justify-between bg-sidebar p-4 md:flex">
            <div className="space-y-8">
              <BrandLogo light className="px-2 pt-2" />
              <SideNav />
            </div>
            <UserBox onOpenProfil={openProfil} />
          </aside>
          <main className="min-w-0 flex-1 pb-20 md:pb-0">
            <div className="flex items-center justify-between bg-sidebar px-4 py-3 md:hidden">
              <BrandLogo light />
              <div className="flex items-center gap-2">
                <button type="button" onClick={openProfil} aria-label="Profil" className="cursor-pointer">
                  <ProfilAvatar className="size-9 text-sm" />
                </button>
                <SignInButton size="sm" variant="secondary" signOutText="Keluar" />
              </div>
            </div>
            <div className="mx-auto max-w-6xl p-4 md:p-8">
              <Outlet />
            </div>
          </main>
          <BottomNav />
          <ProfilDialog open={profilOpen} onOpenChange={setProfilOpen} />
        </div>
      </Authenticated>
    </>
  );
}
