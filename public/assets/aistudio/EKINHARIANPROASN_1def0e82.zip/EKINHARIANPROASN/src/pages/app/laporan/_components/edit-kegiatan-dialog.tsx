import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAction, useMutation } from "convex/react";
import { Sparkles } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";
import { errorMessage } from "@/lib/drive.ts";

const schema = z.object({
  tanggal: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Pilih tanggal"),
  jam: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/, "Jam tidak valid"),
  namaKegiatan: z.string().trim().min(1, "Wajib diisi"),
  uraian: z.string(),
  driveLink: z.union([z.literal(""), z.url("Link tidak valid")]),
});

type FormValues = z.infer<typeof schema>;

// Stored as "HH.mm.ss"; <input type="time"> uses "HH:mm:ss"
const toInputTime = (jam: string) => jam.replaceAll(".", ":");
const fromInputTime = (t: string) => (t.length === 5 ? `${t}:00` : t).replaceAll(":", ".");

type Props = { row: Doc<"laporanHarian"> | null; onOpenChange: (open: boolean) => void };

export default function EditKegiatanDialog({ row, onOpenChange }: Props) {
  const update = useMutation(api.laporan.rows.update);
  const regenerate = useAction(api.laporan.ai.regenerate);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    values: row
      ? { tanggal: row.tanggal, jam: toInputTime(row.jamKegiatan), namaKegiatan: row.namaKegiatan, uraian: row.uraian, driveLink: row.driveLink }
      : { tanggal: "", jam: "", namaKegiatan: "", uraian: "", driveLink: "" },
  });

  const onSubmit = async (values: FormValues) => {
    if (!row) return;
    setSaving(true);
    try {
      await update({
        id: row._id,
        tanggal: values.tanggal,
        jamKegiatan: fromInputTime(values.jam),
        namaKegiatan: values.namaKegiatan,
        uraian: values.uraian,
        driveLink: values.driveLink,
      });
      toast.success("Kegiatan diperbarui");
      onOpenChange(false);
    } catch (e) {
      toast.error(errorMessage(e, "Gagal menyimpan"));
    } finally {
      setSaving(false);
    }
  };

  const askAi = async () => {
    if (!row) return;
    try {
      await regenerate({ id: row._id });
      toast.success("AI sedang menyusun uraian baru");
      onOpenChange(false);
    } catch (e) {
      toast.error(errorMessage(e, "Gagal meminta AI"));
    }
  };

  return (
    <Dialog open={row !== null} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit kegiatan</DialogTitle>
          <DialogDescription>Perubahan hanya disimpan di laporan, file di Google Drive tidak diubah.</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <FormField control={form.control} name="tanggal" render={({ field }) => (
                <FormItem>
                  <FormLabel>Tanggal</FormLabel>
                  <FormControl><Input type="date" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="jam" render={({ field }) => (
                <FormItem>
                  <FormLabel>Jam</FormLabel>
                  <FormControl><Input type="time" step={1} {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="namaKegiatan" render={({ field }) => (
              <FormItem>
                <FormLabel>Nama kegiatan</FormLabel>
                <FormControl><Input placeholder="Input pajak bulan Juli" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="uraian" render={({ field }) => (
              <FormItem>
                <div className="flex items-center justify-between">
                  <FormLabel>Uraian hasil kegiatan</FormLabel>
                  <Button type="button" size="sm" variant="ghost" className="h-7 text-xs" onClick={askAi}>
                    <Sparkles className="size-3.5" /> Minta AI ulang
                  </Button>
                </div>
                <FormControl><Textarea rows={4} placeholder="Tersusunnya rekap pajak bulan Juli..." {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="driveLink" render={({ field }) => (
              <FormItem>
                <FormLabel>Link Google Drive bukti dukung</FormLabel>
                <FormControl><Input placeholder="https://drive.google.com/..." {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Batal</Button>
              <Button type="submit" disabled={saving}>{saving && <Spinner />} Simpan</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
