import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form.tsx";

const schema = z.object({
  nomor: z.coerce.number<number>().int().min(1, "Minimal 1"),
  namaRhk: z.string().trim().min(1, "Wajib diisi"),
  rencanaAksi: z.string().trim().min(1, "Wajib diisi"),
  targetKuantitas: z.coerce.number<number>().min(0, "Tidak boleh negatif"),
  satuan: z.string().trim().min(1, "Wajib diisi"),
  kataKunci: z
    .string()
    .refine((s) => s.split(",").some((k) => k.trim()), "Isi minimal 1 kata kunci"),
});

type FormValues = z.infer<typeof schema>;

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: Doc<"rhk"> | null;
  nextNomor: number;
};

function defaults(editing: Doc<"rhk"> | null, nextNomor: number): FormValues {
  return editing
    ? { ...editing, kataKunci: editing.kataKunci.join(", ") }
    : { nomor: nextNomor, namaRhk: "", rencanaAksi: "", targetKuantitas: 1, satuan: "Laporan", kataKunci: "" };
}

export default function RhkFormDialog({ open, onOpenChange, editing, nextNomor }: Props) {
  const create = useMutation(api.rhk.create);
  const update = useMutation(api.rhk.update);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({ resolver: zodResolver(schema), values: defaults(editing, nextNomor) });

  const onSubmit = async (values: FormValues) => {
    const payload = { ...values, kataKunci: values.kataKunci.split(",") };
    setSaving(true);
    try {
      if (editing) await update({ id: editing._id, ...payload });
      else await create(payload);
      toast.success(editing ? "RHK diperbarui" : "RHK ditambahkan");
      onOpenChange(false);
    } catch (error) {
      toast.error(error instanceof ConvexError ? (error.data as { message: string }).message : "Gagal menyimpan RHK");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit RHK" : "Tambah RHK"}</DialogTitle>
          <DialogDescription>Sesuaikan dengan target SKP Anda.</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-[90px_1fr] gap-3">
              <FormField control={form.control} name="nomor" render={({ field }) => (
                <FormItem>
                  <FormLabel>No. RHK</FormLabel>
                  <FormControl><Input type="number" min={1} {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="namaRhk" render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama RHK</FormLabel>
                  <FormControl><Input placeholder="Menyusun Laporan Pajak" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="rencanaAksi" render={({ field }) => (
              <FormItem>
                <FormLabel>Rencana Aksi</FormLabel>
                <FormControl><Textarea rows={2} placeholder="Melakukan input dan rekap pajak bulanan" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid grid-cols-2 gap-3">
              <FormField control={form.control} name="targetKuantitas" render={({ field }) => (
                <FormItem>
                  <FormLabel>Target SKP</FormLabel>
                  <FormControl><Input type="number" min={0} {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="satuan" render={({ field }) => (
                <FormItem>
                  <FormLabel>Satuan</FormLabel>
                  <FormControl><Input placeholder="Laporan" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="kataKunci" render={({ field }) => (
              <FormItem>
                <FormLabel>Kata kunci pemetaan</FormLabel>
                <FormControl><Input placeholder="pajak, spt, pph" {...field} /></FormControl>
                <FormDescription>Pisahkan dengan koma. Foto yang judulnya mengandung kata ini akan masuk ke RHK ini.</FormDescription>
                <FormMessage />
              </FormItem>
            )} />
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Batal</Button>
              <Button type="submit" disabled={saving}>{saving && <Spinner />} Simpan</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
