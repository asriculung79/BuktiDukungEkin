import { useQuery } from "convex/react";
import { Link } from "react-router-dom";
import { ArrowRight, CalendarDays, FolderSync, Target, Trophy } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { useAuth } from "@/hooks/use-auth.ts";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

const STEPS = [
  { icon: Target, title: "Isi RHK & Rencana Aksi", text: "Masukkan RHK, target SKP, dan kata kunci pemetaan.", to: "/app/rhk" },
  { icon: FolderSync, title: "Hubungkan Google Drive", text: "Pilih folder data mentah foto Timemark.", to: "/app/drive" },
  { icon: CalendarDays, title: "Laporan Harian", text: "Foto dipilah per tanggal dan disusun jadi tabel.", to: "/app/laporan" },
  { icon: Trophy, title: "Rekap Realisasi", text: "Lihat realisasi per RHK dan salin link bukti dukung.", to: "/app/rekap" },
];

export default function DashboardPage() {
  const { user } = useAuth();
  const rhk = useQuery(api.rhk.list, {});
  const totalTarget = rhk?.reduce((s, r) => s + r.targetKuantitas, 0) ?? 0;

  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-2xl bg-sidebar p-6 text-sidebar-foreground md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,oklch(0.8_0.13_80/0.25),transparent_60%)]" />
        <div className="relative">
          <div className="text-sm text-sidebar-foreground/60">Selamat datang,</div>
          <h1 className="pt-1 font-serif text-3xl font-bold text-balance">{user?.profile.name ?? "Pegawai ASN"}</h1>
          <div className="grid grid-cols-2 gap-4 pt-6 sm:max-w-md">
            <div>
              <div className="text-xs text-sidebar-foreground/60">Jumlah RHK</div>
              {rhk === undefined ? <Skeleton className="mt-1 h-8 w-12 bg-white/10" /> : <div className="text-3xl font-bold text-sidebar-primary">{rhk.length}</div>}
            </div>
            <div>
              <div className="text-xs text-sidebar-foreground/60">Total target SKP</div>
              {rhk === undefined ? <Skeleton className="mt-1 h-8 w-12 bg-white/10" /> : <div className="text-3xl font-bold text-sidebar-primary">{totalTarget}</div>}
            </div>
          </div>
        </div>
      </div>

      <div>
        <h2 className="pb-4 text-lg font-semibold">Alur kerja</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((s, i) => (
            <Card key={s.title} className="gap-0 py-5">
              <CardContent className="flex h-full flex-col px-5">
                <div className="flex items-center justify-between">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
                    <s.icon className="size-5" />
                  </div>
                  <span className="font-serif text-2xl font-bold text-muted-foreground/40">0{i + 1}</span>
                </div>
                <div className="pt-4 font-semibold">{s.title}</div>
                <p className="flex-1 pt-1 text-sm text-muted-foreground">{s.text}</p>
                <div className="pt-4">
                  {s.to ? (
                    <Button asChild size="sm" className="w-full">
                      <Link to={s.to}>Buka <ArrowRight className="size-4" /></Link>
                    </Button>
                  ) : (
                    <Button size="sm" variant="secondary" className="w-full" onClick={() => toast("Segera hadir di tahap berikutnya!")}>
                      Segera hadir
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
