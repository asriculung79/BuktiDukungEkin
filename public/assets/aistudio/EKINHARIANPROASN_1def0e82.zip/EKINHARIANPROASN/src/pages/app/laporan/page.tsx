import { useState } from "react";
import { Link } from "react-router-dom";
import { useAction, useMutation, useQuery } from "convex/react";
import { addMonths, format, parse } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { CalendarDays, ChevronLeft, ChevronRight, FolderSync, RefreshCcw } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import { errorMessage } from "@/lib/drive.ts";
import LaporanTable from "./_components/laporan-table.tsx";
import EditKegiatanDialog from "./_components/edit-kegiatan-dialog.tsx";

type Row = Doc<"laporanHarian">;

function MonthSwitcher({ bulan, onChange }: { bulan: string; onChange: (b: string) => void }) {
  const date = parse(bulan, "yyyy-MM", new Date());
  const shift = (n: number) => onChange(format(addMonths(date, n), "yyyy-MM"));
  return (
    <div className="flex items-center gap-1 rounded-lg border bg-card p-1">
      <Button size="icon" variant="ghost" className="size-8" aria-label="Bulan sebelumnya" onClick={() => shift(-1)}><ChevronLeft className="size-4" /></Button>
      <div className="min-w-32 text-center text-sm font-semibold capitalize">{format(date, "MMMM yyyy", { locale: localeId })}</div>
      <Button size="icon" variant="ghost" className="size-8" aria-label="Bulan berikutnya" onClick={() => shift(1)}><ChevronRight className="size-4" /></Button>
    </div>
  );
}

function SyncButton({ disabled }: { disabled: boolean }) {
  const sync = useAction(api.laporan.sync.syncPhotos);
  const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true);
    try {
      const r = await sync({});
      if (r.dipindah === 0) {
        toast(r.dilewati > 0 ? `Tidak ada foto baru. ${r.dilewati} foto dilewati karena tanggal di nama file tidak terbaca.` : "Tidak ada foto baru di folder data mentah.");
      } else {
        toast.success(`${r.dipindah} foto dipindahkan, ${r.kegiatanBaru} kegiatan baru.${r.sisa ? " Masih ada foto lain, klik Proses lagi." : ""}`);
      }
    } catch (e) {
      toast.error(errorMessage(e, "Gagal memproses foto"));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Button onClick={run} disabled={disabled || busy}>
      {busy ? <Spinner /> : <RefreshCcw className="size-4" />} {busy ? "Memproses foto..." : "Proses foto baru"}
    </Button>
  );
}

export default function LaporanPage() {
  const [bulan, setBulan] = useState(() => format(new Date(), "yyyy-MM"));
  const status = useQuery(api.drive.connection.status, {});
  const rows = useQuery(api.laporan.rows.listByMonth, { bulan });
  const remove = useMutation(api.laporan.rows.remove);
  const [editing, setEditing] = useState<Row | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);

  const ready = Boolean(status?.connection?.rawFolderId);

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await remove({ id: deleting._id });
      toast.success("Baris dihapus dari laporan");
    } catch (e) {
      toast.error(errorMessage(e, "Gagal menghapus"));
    }
    setDeleting(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold">Laporan Harian</h1>
          <p className="pt-1 text-muted-foreground">Foto dipindah ke folder TANGGAL/HARIAN, kegiatan yang sama dalam satu hari digabung jadi satu link.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <MonthSwitcher bulan={bulan} onChange={setBulan} />
          <SyncButton disabled={!ready} />
        </div>
      </div>

      {status !== undefined && !ready && (
        <div className="flex flex-col gap-3 rounded-xl border border-accent/40 bg-accent/10 p-4 sm:flex-row sm:items-center">
          <FolderSync className="size-5 shrink-0 text-accent" />
          <p className="flex-1 text-sm">Hubungkan Google Drive dan pilih folder data mentah agar foto bisa diproses.</p>
          <Button asChild size="sm"><Link to="/app/drive">Buka Google Drive</Link></Button>
        </div>
      )}

      {rows === undefined ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}
        </div>
      ) : rows.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon"><CalendarDays /></EmptyMedia>
            <EmptyTitle>Belum ada kegiatan di bulan ini</EmptyTitle>
            <EmptyDescription>Klik "Proses foto baru" untuk memindahkan foto dari folder data mentah dan menyusun laporan.</EmptyDescription>
          </EmptyHeader>
          {ready && <EmptyContent><SyncButton disabled={false} /></EmptyContent>}
        </Empty>
      ) : (
        <LaporanTable rows={rows} onEdit={setEditing} onDelete={setDeleting} />
      )}

      <EditKegiatanDialog row={editing} onOpenChange={(o) => !o && setEditing(null)} />

      <AlertDialog open={deleting !== null} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus kegiatan ini dari laporan?</AlertDialogTitle>
            <AlertDialogDescription>
              "{deleting?.namaKegiatan}" akan dihapus dari tabel. Foto dan folder di Google Drive tetap aman.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
