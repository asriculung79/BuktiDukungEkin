import { useState } from "react";
import { Link } from "react-router-dom";
import { useAction, useQuery } from "convex/react";
import { ChevronLeft, ChevronRight, FolderTree, Target, Trophy, TriangleAlert } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import { errorMessage } from "@/lib/drive.ts";
import RhkRekapCard from "./_components/rhk-rekap-card.tsx";
import { percent } from "./_lib/utils.ts";

function SyncDriveButton({ disabled }: { disabled: boolean }) {
  const sync = useAction(api.rekap.syncDrive);
  const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true);
    try {
      const r = await sync({});
      toast.success(`${r.folderRhk} folder RHK siap, ${r.dipetakan} kegiatan baru dipetakan.${r.sisa ? " Masih ada sisa, klik lagi." : ""}`);
    } catch (e) {
      toast.error(errorMessage(e, "Gagal sinkronisasi folder RHK"));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Button onClick={run} disabled={disabled || busy}>
      {busy ? <Spinner /> : <FolderTree className="size-4" />} {busy ? "Menyinkronkan..." : "Sinkronkan folder RHK"}
    </Button>
  );
}

export default function RekapPage() {
  const [tahun, setTahun] = useState(() => String(new Date().getFullYear()));
  const data = useQuery(api.rekap.byYear, { tahun });
  const status = useQuery(api.drive.connection.status, {});
  const driveReady = Boolean(status?.connection);

  const totalTarget = data?.rhk.reduce((s, r) => s + r.targetKuantitas, 0) ?? 0;
  const totalRealisasi = data?.rhk.reduce((s, r) => s + r.realisasi, 0) ?? 0;
  const overall = percent(totalRealisasi, totalTarget);

  const stats = [
    { label: "Capaian keseluruhan", value: `${overall}%` },
    { label: "Realisasi / Target", value: `${totalRealisasi} / ${totalTarget}` },
    { label: "Total kegiatan", value: String(data?.totalKegiatan ?? 0) },
    { label: "Tanpa RHK", value: String(data?.tanpaRhk ?? 0) },
  ];

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-2xl bg-sidebar p-6 text-sidebar-foreground md:p-8">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,oklch(0.8_0.13_80/0.28),transparent_60%)]" />
        <div className="relative space-y-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-sidebar-primary uppercase">
                <Trophy className="size-4" /> Rekap Realisasi
              </div>
              <h1 className="pt-2 font-serif text-3xl font-bold text-balance">Capaian SKP per RHK</h1>
              <p className="max-w-xl pt-1 text-sm text-sidebar-foreground/65">Kegiatan dipetakan ke RHK berdasarkan kata kunci di judul foto. Satu kegiatan dihitung satu realisasi.</p>
            </div>
            <div className="flex items-center gap-1 rounded-lg border border-sidebar-border bg-sidebar-accent/50 p-1">
              <Button size="icon" variant="ghost" className="size-8 text-sidebar-foreground hover:bg-sidebar-accent" aria-label="Tahun sebelumnya" onClick={() => setTahun(String(Number(tahun) - 1))}><ChevronLeft className="size-4" /></Button>
              <div className="w-14 text-center font-semibold tabular-nums">{tahun}</div>
              <Button size="icon" variant="ghost" className="size-8 text-sidebar-foreground hover:bg-sidebar-accent" aria-label="Tahun berikutnya" onClick={() => setTahun(String(Number(tahun) + 1))}><ChevronRight className="size-4" /></Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border border-sidebar-border bg-sidebar-accent/40 p-4">
                <div className="text-xs text-sidebar-foreground/60">{s.label}</div>
                {data === undefined ? (
                  <Skeleton className="mt-1.5 h-7 w-16 bg-white/10" />
                ) : (
                  <div className="pt-1 font-serif text-2xl font-bold text-sidebar-primary tabular-nums">{s.value}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-3 rounded-xl border bg-card p-4 sm:flex-row sm:items-center">
        <FolderTree className="size-5 shrink-0 text-accent" />
        <p className="flex-1 text-sm text-muted-foreground">
          Buat folder <span className="font-semibold text-foreground">RHK RENCANA AKSI</span> di Google Drive. Setiap RHK mendapat sub folder publik berisi pintasan ke folder kegiatan yang cocok.
        </p>
        {driveReady ? (
          <SyncDriveButton disabled={!data || data.rhk.length === 0} />
        ) : (
          <Button asChild size="sm"><Link to="/app/drive">Hubungkan Google Drive</Link></Button>
        )}
      </div>

      {data !== undefined && data.tanpaRhk > 0 && (
        <div className="flex items-start gap-3 rounded-xl border border-accent/40 bg-accent/10 p-4 text-sm">
          <TriangleAlert className="size-4 shrink-0 translate-y-0.5 text-accent" />
          <p className="flex-1">{data.tanpaRhk} kegiatan belum cocok dengan kata kunci RHK mana pun. Tambahkan kata kunci di <Link to="/app/rhk" className="font-semibold underline">Data RHK</Link>.</p>
        </div>
      )}

      {data === undefined ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 w-full rounded-2xl" />)}
        </div>
      ) : data.rhk.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon"><Target /></EmptyMedia>
            <EmptyTitle>Belum ada RHK</EmptyTitle>
            <EmptyDescription>Isi RHK dan Rencana Aksi beserta kata kunci agar kegiatan bisa direkap.</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button asChild size="sm"><Link to="/app/rhk">Isi Data RHK</Link></Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-4">
          {data.rhk.map((r, i) => <RhkRekapCard key={r._id} rhk={r} index={i} />)}
        </div>
      )}
    </div>
  );
}
