import { useAction } from "convex/react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { AlertTriangle, CalendarDays, Clock, ImageOff, Images } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import { errorMessage, formatTanggal } from "@/lib/drive.ts";

export default function PhotoList({ folderId }: { folderId: string }) {
  const listPhotos = useAction(api.drive.actions.listPhotos);
  const photos = useInfiniteQuery({
    queryKey: ["drivePhotos", folderId],
    queryFn: ({ pageParam }) => listPhotos(pageParam ? { pageToken: pageParam } : {}),
    initialPageParam: null as string | null,
    getNextPageParam: (last) => last.nextPageToken,
  });
  const all = photos.data?.pages.flatMap((p) => p.photos) ?? [];
  const unreadable = all.filter((p) => !p.parsed).length;

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-2">
        <div>
          <CardTitle className="flex items-center gap-2"><Images className="size-5" /> Foto di folder data mentah</CardTitle>
          <CardDescription className="pt-1">Tanggal, jam, dan judul dibaca otomatis dari nama file.</CardDescription>
        </div>
        {photos.data && (
          <div className="flex gap-2">
            <Badge variant="secondary">{all.length} foto</Badge>
            {unreadable > 0 && <Badge variant="destructive">{unreadable} tidak terbaca</Badge>}
          </div>
        )}
      </CardHeader>
      <CardContent>
        {photos.isPending ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
          </div>
        ) : photos.isError ? (
          <div className="flex items-start gap-2 rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
            <AlertTriangle className="size-4 shrink-0" /> {errorMessage(photos.error, "Gagal memuat foto")}
          </div>
        ) : all.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon"><ImageOff /></EmptyMedia>
              <EmptyTitle>Belum ada foto</EmptyTitle>
              <EmptyDescription>Unggah foto Timemark GPS ke folder ini di Google Drive.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {all.map((p) => {
                const t = p.parsed ? formatTanggal(p.parsed.tanggal) : null;
                return (
                  <div key={p.id} className="flex gap-3 rounded-lg border p-2.5">
                    {p.thumbnailLink ? (
                      <img src={p.thumbnailLink} alt="" referrerPolicy="no-referrer" className="size-16 shrink-0 rounded-md bg-muted object-cover" />
                    ) : (
                      <div className="flex size-16 shrink-0 items-center justify-center rounded-md bg-muted"><Images className="size-5 text-muted-foreground" /></div>
                    )}
                    <div className="min-w-0 flex-1 space-y-1">
                      {p.parsed && t ? (
                        <>
                          <div className="line-clamp-2 text-sm font-medium">{p.parsed.judul}</div>
                          <div className="flex flex-wrap gap-x-3 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1"><CalendarDays className="size-3" /> {t.hari}, {t.tanggal}</span>
                            <span className="flex items-center gap-1"><Clock className="size-3" /> {p.parsed.jam}</span>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="truncate text-sm font-medium">{p.name}</div>
                          <div className="text-xs text-destructive">Tanggal tidak terbaca dari nama file</div>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            {photos.hasNextPage && (
              <div className="flex justify-center">
                <Button variant="secondary" onClick={() => photos.fetchNextPage()} disabled={photos.isFetchingNextPage}>
                  {photos.isFetchingNextPage && <Spinner />} Muat lebih banyak
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
