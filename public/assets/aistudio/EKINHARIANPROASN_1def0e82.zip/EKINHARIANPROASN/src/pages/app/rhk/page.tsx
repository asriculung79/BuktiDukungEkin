import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Pencil, Plus, Target, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import RhkFormDialog from "./_components/rhk-form-dialog.tsx";

export default function RhkPage() {
  const rhk = useQuery(api.rhk.list, {});
  const remove = useMutation(api.rhk.remove);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Doc<"rhk"> | null>(null);
  const [deleting, setDeleting] = useState<Doc<"rhk"> | null>(null);

  const nextNomor = (rhk?.reduce((m, r) => Math.max(m, r.nomor), 0) ?? 0) + 1;
  const openForm = (item: Doc<"rhk"> | null) => {
    setEditing(item);
    setFormOpen(true);
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await remove({ id: deleting._id });
      toast.success("RHK dihapus");
    } catch {
      toast.error("Gagal menghapus RHK");
    }
    setDeleting(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl font-bold">Data RHK &amp; Rencana Aksi</h1>
          <p className="pt-1 text-muted-foreground">Sesuai target SKP Anda. Kata kunci dipakai untuk memetakan foto bukti dukung.</p>
        </div>
        <Button onClick={() => openForm(null)}><Plus className="size-4" /> Tambah RHK</Button>
      </div>

      {rhk === undefined ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
        </div>
      ) : rhk.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon"><Target /></EmptyMedia>
            <EmptyTitle>Belum ada RHK</EmptyTitle>
            <EmptyDescription>Tambahkan RHK pertama Anda, misalnya "Menyusun Laporan Pajak" dengan kata kunci "pajak".</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" onClick={() => openForm(null)}><Plus className="size-4" /> Tambah RHK</Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="space-y-3">
          {rhk.map((r) => (
            <Card key={r._id} className="py-0">
              <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-start">
                <div className="flex size-12 shrink-0 flex-col items-center justify-center rounded-lg bg-sidebar text-sidebar-primary">
                  <span className="text-[9px] font-semibold tracking-widest text-sidebar-foreground/60">RHK</span>
                  <span className="font-serif text-lg leading-none font-bold">{r.nomor}</span>
                </div>
                <div className="min-w-0 flex-1 space-y-2">
                  <div className="font-semibold break-words">{r.namaRhk}</div>
                  <p className="text-sm break-words text-muted-foreground">{r.rencanaAksi}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {r.kataKunci.map((k) => <Badge key={k} variant="secondary">{k}</Badge>)}
                  </div>
                </div>
                <div className="flex items-center justify-between gap-4 sm:flex-col sm:items-end">
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">Target</div>
                    <div className="font-semibold">{r.targetKuantitas} {r.satuan}</div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" aria-label="Edit" onClick={() => openForm(r)}><Pencil className="size-4" /></Button>
                    <Button size="icon" variant="ghost" aria-label="Hapus" onClick={() => setDeleting(r)}><Trash2 className="size-4 text-destructive" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <RhkFormDialog open={formOpen} onOpenChange={setFormOpen} editing={editing} nextNomor={nextNomor} />

      <AlertDialog open={deleting !== null} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus RHK {deleting?.nomor}?</AlertDialogTitle>
            <AlertDialogDescription>{deleting?.namaRhk} akan dihapus permanen.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
