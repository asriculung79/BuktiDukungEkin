import { Copy, ExternalLink, Images, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table.tsx";
import { formatTanggal } from "@/lib/drive.ts";

type Row = Doc<"laporanHarian">;
type Props = { rows: Row[]; onEdit: (row: Row) => void; onDelete: (row: Row) => void };

const copy = async (text: string, label: string) => {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(`${label} disalin`);
  } catch {
    toast.error("Gagal menyalin");
  }
};

function Uraian({ row }: { row: Row }) {
  if (row.uraianStatus === "pending") {
    return (
      <div className="space-y-1.5">
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-3/4" />
        <span className="text-xs text-muted-foreground">AI sedang menyusun...</span>
      </div>
    );
  }
  if (row.uraianStatus === "error" && !row.uraian) {
    return <span className="text-xs text-destructive">Uraian AI gagal dibuat. Klik edit untuk mengisi atau minta AI ulang.</span>;
  }
  return <p className="text-sm break-words whitespace-pre-wrap">{row.uraian}</p>;
}

function Actions({ row, onEdit, onDelete }: { row: Row } & Omit<Props, "rows">) {
  return (
    <div className="flex gap-0.5">
      <Button size="icon" variant="ghost" className="size-8" aria-label="Edit" onClick={() => onEdit(row)}><Pencil className="size-4" /></Button>
      <Button size="icon" variant="ghost" className="size-8" aria-label="Hapus" onClick={() => onDelete(row)}><Trash2 className="size-4 text-destructive" /></Button>
    </div>
  );
}

function DriveLink({ row }: { row: Row }) {
  if (!row.driveLink) return <span className="text-xs text-muted-foreground">-</span>;
  return (
    <div className="flex items-center gap-1">
      <Button asChild size="sm" variant="secondary" className="h-8">
        <a href={row.driveLink} target="_blank" rel="noreferrer"><ExternalLink className="size-3.5" /> Buka</a>
      </Button>
      <Button size="icon" variant="ghost" className="size-8" aria-label="Salin link" onClick={() => copy(row.driveLink, "Link")}>
        <Copy className="size-3.5" />
      </Button>
    </div>
  );
}

export default function LaporanTable({ rows, onEdit, onDelete }: Props) {
  return (
    <>
      {/* Desktop table */}
      <div className="hidden overflow-hidden rounded-xl border bg-card lg:block">
        <Table>
          <TableHeader className="bg-sidebar [&_th]:text-sidebar-foreground">
            <TableRow className="hover:bg-sidebar">
              <TableHead className="w-10">No</TableHead>
              <TableHead>Hari</TableHead>
              <TableHead>Tanggal</TableHead>
              <TableHead>Jam</TableHead>
              <TableHead className="w-[22%]">Nama Kegiatan</TableHead>
              <TableHead className="w-[32%]">Uraian Hasil Kegiatan</TableHead>
              <TableHead>Bukti Dukung</TableHead>
              <TableHead className="w-20" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row, i) => {
              const { hari, tanggal } = formatTanggal(row.tanggal);
              return (
                <TableRow key={row._id} className="align-top">
                  <TableCell className="font-medium">{i + 1}</TableCell>
                  <TableCell>{hari}</TableCell>
                  <TableCell className="tabular-nums">{tanggal}</TableCell>
                  <TableCell className="tabular-nums">{row.jamKegiatan}</TableCell>
                  <TableCell className="whitespace-normal">
                    <div className="font-medium break-words">{row.namaKegiatan}</div>
                    <Badge variant="secondary" className="mt-1.5 gap-1"><Images className="size-3" /> {row.jumlahFoto} foto</Badge>
                  </TableCell>
                  <TableCell className="whitespace-normal"><Uraian row={row} /></TableCell>
                  <TableCell><DriveLink row={row} /></TableCell>
                  <TableCell><Actions row={row} onEdit={onEdit} onDelete={onDelete} /></TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Mobile / tablet cards */}
      <div className="space-y-3 lg:hidden">
        {rows.map((row, i) => {
          const { hari, tanggal } = formatTanggal(row.tanggal);
          return (
            <div key={row._id} className="space-y-3 rounded-xl border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-xs text-muted-foreground tabular-nums">
                    #{i + 1} &middot; {hari}, {tanggal} &middot; {row.jamKegiatan}
                  </div>
                  <div className="pt-1 font-semibold break-words">{row.namaKegiatan}</div>
                </div>
                <Actions row={row} onEdit={onEdit} onDelete={onDelete} />
              </div>
              <Uraian row={row} />
              <div className="flex items-center justify-between gap-2">
                <Badge variant="secondary" className="gap-1"><Images className="size-3" /> {row.jumlahFoto} foto</Badge>
                <DriveLink row={row} />
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
