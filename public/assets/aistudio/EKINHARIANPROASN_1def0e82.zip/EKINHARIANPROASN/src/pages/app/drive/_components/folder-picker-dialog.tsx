import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { useQuery as useTanstackQuery } from "@tanstack/react-query";
import { ChevronRight, Folder, FolderOpen, Home, Search } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { errorMessage } from "@/lib/drive.ts";
import { cn } from "@/lib/utils.ts";

type Crumb = { id: string; name: string };
type Props = { open: boolean; onOpenChange: (open: boolean) => void };

export default function FolderPickerDialog({ open, onOpenChange }: Props) {
  const listFolders = useAction(api.drive.actions.listFolders);
  const selectFolder = useMutation(api.drive.connection.selectFolder);
  const [path, setPath] = useState<Crumb[]>([]);
  const [selected, setSelected] = useState<Crumb | null>(null);
  const [search, setSearch] = useState("");
  const [debounced] = useDebounce(search.trim(), 400);
  const parentId = path.at(-1)?.id ?? "root";

  const folders = useTanstackQuery({
    queryKey: ["driveFolders", parentId, debounced],
    queryFn: () => listFolders(debounced ? { search: debounced } : { parentId }),
    enabled: open,
  });

  const openFolder = (f: Crumb) => {
    setSearch("");
    setPath(debounced ? [f] : [...path, f]);
    setSelected(f);
  };

  const save = async () => {
    if (!selected) return;
    try {
      await selectFolder({ folderId: selected.id, folderName: selected.name });
      toast.success(`Folder "${selected.name}" dipilih`);
      onOpenChange(false);
    } catch (e) {
      toast.error(errorMessage(e, "Gagal menyimpan folder"));
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Pilih folder data mentah</DialogTitle>
          <DialogDescription>Folder tempat foto Timemark GPS Anda tersimpan.</DialogDescription>
        </DialogHeader>
        <div className="relative">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" placeholder="Cari nama folder..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        {!debounced && (
          <div className="flex flex-wrap items-center gap-1 text-sm">
            <button className="flex cursor-pointer items-center gap-1 rounded px-1.5 py-0.5 hover:bg-muted" onClick={() => { setPath([]); setSelected(null); }}>
              <Home className="size-3.5" /> Drive Saya
            </button>
            {path.map((c, i) => (
              <span key={c.id} className="flex items-center gap-1">
                <ChevronRight className="size-3.5 text-muted-foreground" />
                <button className="cursor-pointer rounded px-1.5 py-0.5 hover:bg-muted" onClick={() => { setPath(path.slice(0, i + 1)); setSelected(c); }}>{c.name}</button>
              </span>
            ))}
          </div>
        )}
        <div className="h-72 space-y-1 overflow-y-auto rounded-lg border p-1.5">
          {folders.isPending ? (
            Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)
          ) : folders.isError ? (
            <p className="p-4 text-sm text-destructive">{errorMessage(folders.error, "Gagal memuat folder")}</p>
          ) : folders.data.length === 0 ? (
            <p className="p-4 text-center text-sm text-muted-foreground">Tidak ada sub folder</p>
          ) : (
            folders.data.map((f) => (
              <div
                key={f.id}
                className={cn("flex items-center gap-2 rounded-md px-2 py-1.5 text-sm", selected?.id === f.id ? "bg-secondary" : "hover:bg-muted")}
              >
                <button className="flex min-w-0 flex-1 cursor-pointer items-center gap-2 text-left" onClick={() => setSelected(f)}>
                  {selected?.id === f.id ? <FolderOpen className="size-4 shrink-0 text-accent" /> : <Folder className="size-4 shrink-0 text-muted-foreground" />}
                  <span className="truncate">{f.name}</span>
                </button>
                <Button size="icon" variant="ghost" className="size-7" onClick={() => openFolder(f)} aria-label="Buka folder">
                  <ChevronRight className="size-4" />
                </Button>
              </div>
            ))
          )}
        </div>
        <DialogFooter className="items-center sm:justify-between">
          <span className="truncate text-sm text-muted-foreground">{selected ? `Dipilih: ${selected.name}` : "Belum ada folder dipilih"}</span>
          <Button onClick={save} disabled={!selected}>Gunakan folder ini</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
