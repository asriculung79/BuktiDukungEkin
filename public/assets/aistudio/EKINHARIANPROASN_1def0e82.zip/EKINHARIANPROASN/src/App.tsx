import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AuthCallback from "./pages/auth/Callback.tsx";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import AppLayout from "./pages/app/layout.tsx";
import DashboardPage from "./pages/app/dashboard/page.tsx";
import RhkPage from "./pages/app/rhk/page.tsx";
import DrivePage from "./pages/app/drive/page.tsx";
import DriveCallbackPage from "./pages/app/drive/callback/page.tsx";
import LaporanPage from "./pages/app/laporan/page.tsx";
import RekapPage from "./pages/app/rekap/page.tsx";

export default function App() {
  return (
    <DefaultProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/app" element={<AppLayout />}>
            <Route index element={<DashboardPage />} />
            <Route path="rhk" element={<RhkPage />} />
            <Route path="drive" element={<DrivePage />} />
            <Route path="drive/callback" element={<DriveCallbackPage />} />
            <Route path="laporan" element={<LaporanPage />} />
            <Route path="rekap" element={<RekapPage />} />
          </Route>
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
